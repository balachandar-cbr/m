using System.Collections.Generic;
using UnityEngine;

public static class ExerciseBuilder
{
    public const string Title = "Exercise03 Eye Movement Coverage";

    public static void Build()
    {
        ARVR.ClearDefaults();
        ARVR.MakeSun(1f);
        var cam = ARVR.MakeCamera(new Vector3(0, 1.6f, 0), Vector3.zero);
        ARVR.Prim(PrimitiveType.Plane, "Ground", Vector3.zero, new Vector3(6, 1, 6), ARVR.Mat("Ex3_Ground", new Color(0.45f, 0.40f, 0.38f), 0f, 0.1f));

        // 5 columns x 3 rows of targets around the viewer (yaw -60..60, pitch +25/0/-25), radius 8 m
        float[] yaws = { -60f, -30f, 0f, 30f, 60f };
        float[] pitches = { 25f, 0f, -25f };
        var list = new List<Transform>();
        int n = 0;
        for (int r = 0; r < pitches.Length; r++)
            for (int c = 0; c < yaws.Length; c++)
            {
                Vector3 dir = Quaternion.Euler(-pitches[r], yaws[c], 0f) * Vector3.forward;
                Color col = Color.HSVToRGB(n / 15f, 0.8f, 0.95f);
                var s = ARVR.Prim(PrimitiveType.Sphere, "Target_r" + r + "_c" + c, cam.transform.position + dir * 8f, Vector3.one * 0.8f, ARVR.Mat("Ex3_Target" + n, col, 0.2f, 0.8f));
                list.Add(s.transform); n++;
            }

        var sweep = cam.gameObject.AddComponent<EyeSweep>();
        sweep.targets = list.ToArray();
    }
}
