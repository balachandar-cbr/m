using System.Collections.Generic;
using System.IO;
using UnityEngine;

/// <summary>
/// Sweeping coverage of eye (gaze) movements.  The viewing direction is swept
/// Left->Right, Right->Left, Top->Bottom, Bottom->Top and then in a raster scan.
/// Every target that enters the gaze cone is marked "covered"; gaze samples are logged to a CSV.
/// With a headset connected the real head pose is used instead of the automatic sweep.
/// Keys:  M = auto/manual (manual = hold right mouse)   R = restart   Space = save CSV log
/// </summary>
public class EyeSweep : MonoBehaviour
{
    public Transform[] targets;
    public float angularSpeed = 40f;     // degrees / second
    public float gazeCone = 7f;          // degrees: target counts as "looked at"
    public bool autoSweep = true;

    class Phase { public string name; public Vector2[] pts; public Phase(string n, params Vector2[] p) { name = n; pts = p; } }
    Phase[] phases;
    int phaseIdx, ptIdx;
    Vector2 gaze;                        // x = yaw, y = pitch (degrees, +pitch = up)
    bool[] covered;
    Renderer[] rends;
    Color[] orig;
    List<string> log = new List<string>();
    float clock, logTimer;
    string current = "-", savedMsg = "";
    int sweepsDone;

    void Start()
    {
        phases = new[]
        {
            new Phase("Left -> Right",  new Vector2(-65, 0), new Vector2(65, 0)),
            new Phase("Right -> Left",  new Vector2(-65, 0)),
            new Phase("Top -> Bottom",  new Vector2(0, 0), new Vector2(0, 30), new Vector2(0, -30)),
            new Phase("Bottom -> Top",  new Vector2(0, 30)),
            new Phase("Raster scan",    new Vector2(-65, 25), new Vector2(65, 25), new Vector2(65, 0), new Vector2(-65, 0), new Vector2(-65, -25), new Vector2(65, -25)),
        };
        covered = new bool[targets.Length];
        rends = new Renderer[targets.Length];
        orig = new Color[targets.Length];
        for (int i = 0; i < targets.Length; i++) { rends[i] = targets[i].GetComponent<Renderer>(); orig[i] = rends[i].material.color; }
        log.Add("time_s,yaw_deg,pitch_deg,target_in_gaze");
        Restart();
    }

    void Restart()
    {
        phaseIdx = 0; ptIdx = 0; gaze = phases[0].pts[0]; clock = 0; sweepsDone = 0;
        for (int i = 0; i < covered.Length; i++) { covered[i] = false; ARVR.SetEmission(rends[i].material, Color.black); }
        log.Clear(); log.Add("time_s,yaw_deg,pitch_deg,target_in_gaze");
    }

    bool HeadsetActive { get { return UnityEngine.XR.XRSettings.isDeviceActive; } }

    void Update()
    {
        clock += Time.deltaTime;
        if (InputCompat.GetKeyDown(KeyCode.M)) autoSweep = !autoSweep;
        if (InputCompat.GetKeyDown(KeyCode.R)) Restart();
        if (InputCompat.GetKeyDown(KeyCode.Space)) Save();

        if (HeadsetActive)
        {
            float yaw = Mathf.DeltaAngle(0, transform.eulerAngles.y), pit = -Mathf.DeltaAngle(0, transform.eulerAngles.x);
            gaze = new Vector2(yaw, pit);                       // real head tracking
        }
        else
        {
            if (autoSweep)
            {
                Vector2 goal = phases[phaseIdx].pts[ptIdx];
                gaze = Vector2.MoveTowards(gaze, goal, angularSpeed * Time.deltaTime);
                if ((gaze - goal).sqrMagnitude < 0.01f)
                {
                    ptIdx++;
                    if (ptIdx >= phases[phaseIdx].pts.Length) { ptIdx = 0; phaseIdx++; if (phaseIdx >= phases.Length) { phaseIdx = 0; sweepsDone++; if (sweepsDone == 1) Save(); } }
                }
            }
            else if (InputCompat.MouseButton(1))
            {
                gaze += new Vector2(InputCompat.MouseDelta.x, InputCompat.MouseDelta.y) * 3f;
                gaze.y = Mathf.Clamp(gaze.y, -85f, 85f);
            }
            transform.rotation = Quaternion.Euler(-gaze.y, gaze.x, 0f);
        }

        current = "-";
        Vector3 f = transform.forward;
        for (int i = 0; i < targets.Length; i++)
        {
            float ang = Vector3.Angle(f, targets[i].position - transform.position);
            if (ang < gazeCone)
            {
                current = targets[i].name;
                if (!covered[i]) { covered[i] = true; ARVR.SetEmission(rends[i].material, orig[i] * 1.6f); }
            }
        }

        logTimer += Time.deltaTime;
        if (logTimer >= 0.1f) { logTimer = 0; log.Add(clock.ToString("F2") + "," + gaze.x.ToString("F1") + "," + gaze.y.ToString("F1") + "," + current); }
    }

    int CoveredCount() { int c = 0; foreach (var b in covered) if (b) c++; return c; }

    void Save()
    {
        string p = Path.Combine(Application.persistentDataPath, "gaze_log.csv");
        try { File.WriteAllLines(p, log.ToArray()); savedMsg = "Gaze log saved: " + p; } catch (System.Exception e) { savedMsg = "Could not save: " + e.Message; }
    }

    void OnGUI()
    {
        string mode = HeadsetActive ? "HEADSET (real head tracking)" : (autoSweep ? "AUTO SWEEP" : "MANUAL (hold right mouse)");
        string ph = (autoSweep && !HeadsetActive) ? phases[phaseIdx].name : "-";
        int c = CoveredCount();
        ARVR.Hud("SWEEPING COVERAGE OF EYE MOVEMENTS\nMode: " + mode + "   [M] toggle   [R] restart   [Space] save CSV\nSweep phase: " + ph + "\nGaze  yaw " + gaze.x.ToString("F0") + "   pitch " + gaze.y.ToString("F0") +
                 "\nLooking at: " + current + "\nCoverage: " + c + " / " + targets.Length + "  (" + Mathf.RoundToInt(100f * c / targets.Length) + "%)   sweeps done: " + sweepsDone + "\n" + savedMsg, 14);
        ARVR.Text(new Rect(Screen.width / 2 - 15, Screen.height / 2 - 18, 30, 36), "+", 26, TextAnchor.MiddleCenter, true);
    }
}
