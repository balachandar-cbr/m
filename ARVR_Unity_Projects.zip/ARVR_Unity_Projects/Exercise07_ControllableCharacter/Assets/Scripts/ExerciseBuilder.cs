using UnityEngine;

public static class ExerciseBuilder
{
    public const string Title = "Exercise07 Controllable Character";

    public static void Build()
    {
        ARVR.ClearDefaults();
        ARVR.MakeSun(1f);
        var cam = ARVR.MakeCamera(new Vector3(0, 5f, -10f), new Vector3(30, 0, 0));
        ARVR.Prim(PrimitiveType.Plane, "Ground", Vector3.zero, new Vector3(20, 1, 20), ARVR.Mat("Ex7_Ground", new Color(0.22f, 0.5f, 0.3f), 0f, 0.1f));

        var player = ARVR.Prim(PrimitiveType.Cube, "Player", new Vector3(0, 0.5f, 0), Vector3.one, ARVR.Mat("Ex7_Player", new Color(0.8f, 0.82f, 0.9f)));
        var pm = player.AddComponent<PlayerMovement>();
        pm.speed = 5f;

        var follow = cam.gameObject.AddComponent<CameraFollow>();
        follow.target = player.transform;
    }
}
