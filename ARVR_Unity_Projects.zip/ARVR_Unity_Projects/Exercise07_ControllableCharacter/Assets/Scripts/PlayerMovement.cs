using UnityEngine;

/// <summary>Moves the cube with W/A/S/D or the arrow keys (the record's script, made input-system safe).</summary>
public class PlayerMovement : MonoBehaviour
{
    Vector3 movement;
    public float speed = 5f;

    void Update()
    {
        movement.x = InputCompat.Horizontal() * speed * Time.deltaTime;
        movement.z = InputCompat.Vertical() * speed * Time.deltaTime;
        transform.Translate(movement, Space.Self);
    }

    void OnGUI() { ARVR.Hud("W / Up : Move Forward\nS / Down : Move Backward\nA / Left : Move Left\nD / Right : Move Right", 15); }
}

/// <summary>Camera keeps the same offset (0,5,-10) from the player so the cube never leaves the screen.</summary>
public class CameraFollow : MonoBehaviour
{
    public Transform target;
    Vector3 offset;
    void Start() { if (target != null) offset = transform.position - target.position; }
    void LateUpdate() { if (target != null) transform.position = target.position + offset; }
}
