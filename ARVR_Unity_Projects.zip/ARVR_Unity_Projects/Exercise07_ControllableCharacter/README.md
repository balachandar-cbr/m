# Exercise 7: Scene Creation with a Controllable Character
Project name in the record: **Controllable Character**

PlayerMovement.cs: cube moves with WASD/arrows; camera follows.

## How to run
1. Unity Hub > **Add > Add project from disk** > select this folder (accept the editor version prompt; any Unity 2022.3+ / Unity 6 works, Built-in or URP).
2. Wait for compile. Then either
   - open any scene (or an empty one) and press **Play** - the scene builds itself, or
   - menu **AR-VR Lab > Build Exercise Scene** to create and save `Assets/Scenes/...unity` for your screenshots, then press Play.
3. Take the output screenshot from the Game view for the record.

Source files are in `Assets/Scripts`. Works with the old Input Manager and the new Input System.
