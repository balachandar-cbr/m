using System.IO;
using UnityEngine;
using UnityEngine.Video;

/// <summary>
/// VR/3D video viewer. Plays a VideoClip (assign in Inspector) OR an mp4 at
/// Assets/StreamingAssets/sample.mp4 OR any URL. With no video it runs an animated demo
/// screen so the controls can still be tested.  Controls: Play, Pause, Stop, Replay + features.
/// </summary>
public class VideoScreen : MonoBehaviour
{
    public Renderer screen;
    public Light sun;
    public VideoClip clip;
    public string url = "";
    public bool playOnStart = true;
    public bool loop = true;
    public bool mute = false;

    VideoPlayer vp;
    RenderTexture rt;
    Texture2D demoTex;
    Color32[] demoPix;
    bool demoPlaying;
    float demoTime, demoLength = 20f;
    float speed = 1f;
    int sizeIdx = 1;
    bool theatre;
    Vector3 baseScale;
    string status = "";
    static readonly float[] Sizes = { 0.6f, 1f, 1.4f };
    static readonly string[] SizeNames = { "Small", "Medium", "Large" };

    void Start()
    {
        baseScale = screen.transform.localScale;
        string path = url;
        if (clip == null && string.IsNullOrEmpty(path))
        {
            string p = Path.Combine(Application.streamingAssetsPath, "sample.mp4");
            if (File.Exists(p)) path = p;
        }

        if (clip != null || !string.IsNullOrEmpty(path))
        {
            vp = gameObject.AddComponent<VideoPlayer>();
            vp.playOnAwake = false;
            vp.isLooping = loop;
            vp.renderMode = VideoRenderMode.RenderTexture;
            rt = new RenderTexture(1280, 720, 0);
            vp.targetTexture = rt;
            vp.audioOutputMode = VideoAudioOutputMode.Direct;
            if (clip != null) { vp.source = VideoSource.VideoClip; vp.clip = clip; }
            else { vp.source = VideoSource.Url; vp.url = path.StartsWith("http") ? path : new System.Uri(path).AbsoluteUri; }
            vp.errorReceived += (v, msg) => { status = "Video error: " + msg; };
            screen.material.mainTexture = rt;
            status = "Playing video";
            if (playOnStart) vp.Play();
        }
        else
        {
            demoTex = new Texture2D(160, 90, TextureFormat.RGBA32, false);
            demoPix = new Color32[160 * 90];
            screen.material.mainTexture = demoTex;
            demoPlaying = playOnStart;
            status = "DEMO mode - put an mp4 at Assets/StreamingAssets/sample.mp4 or assign a Video Clip on 'VideoScreen'";
        }
    }

    public void Play() { if (vp != null) vp.Play(); else demoPlaying = true; }
    public void Pause() { if (vp != null) vp.Pause(); else demoPlaying = false; }
    public void Stop() { if (vp != null) vp.Stop(); else { demoPlaying = false; demoTime = 0f; } }
    public void Replay() { if (vp != null) { vp.Stop(); vp.Play(); } else { demoTime = 0f; demoPlaying = true; } }
    public bool IsPlaying { get { return vp != null ? vp.isPlaying : demoPlaying; } }

    void Update()
    {
        if (InputCompat.GetKeyDown(KeyCode.Space)) { if (IsPlaying) Pause(); else Play(); }
        if (vp != null) return;

        if (demoPlaying)
        {
            demoTime += Time.deltaTime * speed;
            if (demoTime > demoLength) { if (loop) demoTime = 0f; else { demoPlaying = false; demoTime = demoLength; } }
        }
        int w = 160, h = 90;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                float hue = Mathf.Repeat(x / (float)w * 0.6f + y / (float)h * 0.3f + demoTime * 0.08f, 1f);
                Color c = Color.HSVToRGB(hue, 0.55f, 0.9f);
                float bar = Mathf.Abs(x - Mathf.Repeat(demoTime * 20f, w));
                if (bar < 3f) c = Color.white;
                demoPix[y * w + x] = c;
            }
        demoTex.SetPixels32(demoPix);
        demoTex.Apply(false);
    }

    void OnGUI()
    {
        float k = ARVR.GuiScale();
        var old = GUI.matrix;
        GUI.matrix = Matrix4x4.Scale(new Vector3(k, k, 1f));
        float W = Screen.width / k, H = Screen.height / k;

        GUI.Label(new Rect(12, 8, W - 24, 40), "VR Video Viewer   |   Hold RIGHT MOUSE to look around   |   SPACE = play/pause");
        GUI.Label(new Rect(12, 28, W - 24, 40), status);

        GUILayout.BeginArea(new Rect(W / 2 - 340, H - 130, 680, 120), GUI.skin.box);
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Play")) Play();
        if (GUILayout.Button("Pause")) Pause();
        if (GUILayout.Button("Stop")) Stop();
        if (GUILayout.Button("Replay")) Replay();
        GUILayout.EndHorizontal();

        float len = vp != null ? (float)vp.length : demoLength;
        float pos = vp != null ? (float)vp.time : demoTime;
        if (len > 0.1f)
        {
            float np = GUILayout.HorizontalSlider(pos, 0f, len);
            if (Mathf.Abs(np - pos) > 0.01f && GUI.changed) { if (vp != null) vp.time = np; else demoTime = np; }
            GUILayout.Label(pos.ToString("0.0") + " s / " + len.ToString("0.0") + " s");
        }

        GUILayout.BeginHorizontal();
        bool nl = GUILayout.Toggle(loop, "Loop"); if (nl != loop) { loop = nl; if (vp != null) vp.isLooping = loop; }
        bool nm = GUILayout.Toggle(mute, "Mute"); if (nm != mute) { mute = nm; if (vp != null && vp.isPrepared && vp.audioTrackCount > 0) vp.SetDirectAudioMute(0, mute); }
        if (GUILayout.Button("Speed " + speed + "x")) { speed = speed >= 2f ? 0.5f : speed + 0.5f; if (vp != null) vp.playbackSpeed = speed; }
        if (GUILayout.Button("Screen: " + SizeNames[sizeIdx])) { sizeIdx = (sizeIdx + 1) % Sizes.Length; screen.transform.localScale = baseScale * Sizes[sizeIdx]; }
        bool nt = GUILayout.Toggle(theatre, "Theatre mode"); if (nt != theatre) { theatre = nt; if (sun != null) sun.intensity = theatre ? 0.05f : 0.7f; }
        GUILayout.EndHorizontal();
        GUILayout.EndArea();
        GUI.matrix = old;
    }
}
