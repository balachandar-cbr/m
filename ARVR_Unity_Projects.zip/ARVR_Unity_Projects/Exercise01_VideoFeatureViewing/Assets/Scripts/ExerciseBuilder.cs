using UnityEngine;

public static class ExerciseBuilder
{
    public const string Title = "Exercise01 Video Feature Viewing";

    public static void Build()
    {
        ARVR.ClearDefaults();
        var sun = ARVR.MakeSun(0.7f);
        var cam = ARVR.MakeCamera(new Vector3(0, 1.6f, 0), Vector3.zero, null, true, new Color(0.03f, 0.04f, 0.07f));
        var look = cam.gameObject.AddComponent<FreeCam>();
        look.allowMove = false;                       // viewer sits in the "seat" and only looks around

        var dark = ARVR.Mat("Ex1_Dark", new Color(0.10f, 0.11f, 0.14f), 0f, 0.7f);
        ARVR.Prim(PrimitiveType.Plane, "Floor", Vector3.zero, new Vector3(4, 1, 4), dark);
        ARVR.Prim(PrimitiveType.Cube, "BackWall", new Vector3(0, 4, 12), new Vector3(40, 12, 0.5f), dark);
        ARVR.Prim(PrimitiveType.Cube, "ScreenFrame", new Vector3(0, 2.4f, 6.9f), new Vector3(8.4f, 4.8f, 0.15f), ARVR.Mat("Ex1_Frame", new Color(0.02f, 0.02f, 0.03f)));
        ARVR.MakePointLight("ScreenGlow", new Vector3(0, 2.4f, 5f), new Color(0.6f, 0.8f, 1f), 1.2f, 14f);

        var screen = ARVR.Prim(PrimitiveType.Quad, "VideoScreen", new Vector3(0, 2.4f, 6.8f), new Vector3(8f, 4.5f, 1f), ARVR.UnlitTex("Ex1_Screen"), null, false);
        var vs = screen.AddComponent<VideoScreen>();
        vs.screen = screen.GetComponent<Renderer>();
        vs.sun = sun;
    }
}
