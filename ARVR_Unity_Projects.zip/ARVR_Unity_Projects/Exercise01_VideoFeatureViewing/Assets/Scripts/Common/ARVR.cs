using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

/// <summary>Small helper library shared by every exercise (scene root, materials, primitives, GUI).</summary>
public static class ARVR
{
    public const string RootName = "__Exercise";

    public static bool HasRoot() { return GameObject.Find(RootName) != null; }

    public static Transform Root()
    {
        var r = GameObject.Find(RootName);
        if (r == null) r = new GameObject(RootName);
        return r.transform;
    }

    public static void Kill(Object o) { if (o != null) Object.DestroyImmediate(o); }

    /// <summary>Removes the default camera / light of a template scene so the builder can create its own.</summary>
    public static void ClearDefaults()
    {
        foreach (var c in Object.FindObjectsByType<Camera>(FindObjectsSortMode.None)) if (c != null) Kill(c.gameObject);
        foreach (var l in Object.FindObjectsByType<Light>(FindObjectsSortMode.None)) if (l != null) Kill(l.gameObject);
    }

    // ---------------------------------------------------------------- shaders / materials
    public static bool UsingSRP { get { return UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline != null; } }

    public static Shader Pick(params string[] names)
    {
        foreach (var n in names) { var s = Shader.Find(n); if (s != null) return s; }
        return Shader.Find("Sprites/Default");
    }
    public static Shader LitShader() { return UsingSRP ? Pick("Universal Render Pipeline/Lit", "Standard") : Pick("Standard", "Universal Render Pipeline/Lit"); }
    public static Shader UnlitShader() { return UsingSRP ? Pick("Universal Render Pipeline/Unlit", "Unlit/Color") : Pick("Unlit/Color", "Universal Render Pipeline/Unlit"); }
    public static Shader UnlitTexShader() { return UsingSRP ? Pick("Universal Render Pipeline/Unlit", "Unlit/Texture") : Pick("Unlit/Texture", "Universal Render Pipeline/Unlit"); }

    public static Material Save(Material m)
    {
#if UNITY_EDITOR
        if (!Application.isPlaying)
        {
            if (!AssetDatabase.IsValidFolder("Assets/Materials")) AssetDatabase.CreateFolder("Assets", "Materials");
            string p = AssetDatabase.GenerateUniqueAssetPath("Assets/Materials/" + m.name + ".mat");
            AssetDatabase.CreateAsset(m, p);
        }
#endif
        return m;
    }

    static Material LitRaw(string name, Color c, float metallic, float smooth)
    {
        var m = new Material(LitShader());
        m.name = name;
        m.color = c;
        if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", metallic);
        if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smooth);
        if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", smooth);
        return m;
    }
    public static Material Mat(string name, Color c, float metallic = 0f, float smooth = 0.5f) { return Save(LitRaw(name, c, metallic, smooth)); }

    public static void SetEmission(Material m, Color e)
    {
        m.EnableKeyword("_EMISSION");
        if (m.HasProperty("_EmissionColor")) m.SetColor("_EmissionColor", e);
        m.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
    }
    public static Material Emissive(string name, Color c, float intensity = 2f)
    {
        var m = LitRaw(name, c, 0f, 0.4f);
        SetEmission(m, c * intensity);
        return Save(m);
    }
    public static Material Unlit(string name, Color c)
    {
        var m = new Material(UnlitShader()); m.name = name; m.color = c; return Save(m);
    }
    public static Material UnlitTex(string name)
    {
        var m = new Material(UnlitTexShader()); m.name = name; m.color = Color.white; return Save(m);
    }
    public static Material FromShader(string name, params string[] shaderNames)
    {
        var m = new Material(Pick(shaderNames)); m.name = name; return Save(m);
    }

    // ---------------------------------------------------------------- scene objects
    public static GameObject Prim(PrimitiveType t, string name, Vector3 pos, Vector3 scale, Material mat = null, Transform parent = null, bool collider = true)
    {
        var g = GameObject.CreatePrimitive(t);
        g.name = name;
        g.transform.SetParent(parent != null ? parent : Root(), false);
        g.transform.localPosition = pos;
        g.transform.localScale = scale;
        if (mat != null) g.GetComponent<Renderer>().sharedMaterial = mat;
        if (!collider) Kill(g.GetComponent<Collider>());
        return g;
    }

    public static Camera MakeCamera(Vector3 pos, Vector3 euler, Transform parent = null, bool solidColor = false, Color? bg = null)
    {
        var g = new GameObject("Main Camera");
        g.tag = "MainCamera";
        g.transform.SetParent(parent != null ? parent : Root(), false);
        g.transform.localPosition = pos;
        g.transform.localEulerAngles = euler;
        var c = g.AddComponent<Camera>();
        c.nearClipPlane = 0.05f;
        c.farClipPlane = 200f;
        if (solidColor) { c.clearFlags = CameraClearFlags.SolidColor; c.backgroundColor = bg ?? Color.black; }
        g.AddComponent<AudioListener>();
        return c;
    }

    public static Light MakeSun(float intensity = 1f)
    {
        var g = new GameObject("Directional Light");
        g.transform.SetParent(Root(), false);
        g.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
        var l = g.AddComponent<Light>();
        l.type = LightType.Directional;
        l.intensity = intensity;
        l.shadows = LightShadows.Soft;
        return l;
    }

    public static Light MakePointLight(string name, Vector3 pos, Color col, float intensity, float range, Transform parent = null)
    {
        var g = new GameObject(name);
        g.transform.SetParent(parent != null ? parent : Root(), false);
        g.transform.localPosition = pos;
        var l = g.AddComponent<Light>();
        l.type = LightType.Point; l.color = col; l.intensity = intensity; l.range = range;
        return l;
    }

    // ---------------------------------------------------------------- GUI helpers (IMGUI: works with no packages)
    public static float GuiScale() { return Mathf.Max(0.5f, Screen.height / 600f); }

    public static GUIStyle Style(int size, TextAnchor anchor = TextAnchor.UpperLeft, bool bold = false, Color? col = null)
    {
        var s = new GUIStyle(GUI.skin.label);
        s.fontSize = Mathf.RoundToInt(size * GuiScale());
        s.alignment = anchor;
        s.fontStyle = bold ? FontStyle.Bold : FontStyle.Normal;
        s.wordWrap = true;
        s.normal.textColor = col ?? Color.white;
        return s;
    }

    /// <summary>Text with a drop shadow so it is readable on any background.</summary>
    public static void Text(Rect r, string text, int size = 14, TextAnchor anchor = TextAnchor.UpperLeft, bool bold = false)
    {
        var sh = Style(size, anchor, bold, new Color(0, 0, 0, 0.85f));
        GUI.Label(new Rect(r.x + 1.5f, r.y + 1.5f, r.width, r.height), text, sh);
        GUI.Label(r, text, Style(size, anchor, bold));
    }

    public static void Hud(string text, int size = 14) { float k = GuiScale(); Text(new Rect(10 * k, 8 * k, Screen.width - 20 * k, Screen.height * 0.5f), text, size); }
}
