using UnityEngine;
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
using UnityEngine.InputSystem;
#endif

/// <summary>
/// Works with BOTH the old Input Manager and the new Input System package, so the lab
/// scripts run no matter which "Active Input Handling" your Unity version uses.
/// </summary>
public static class InputCompat
{
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
    static Key Map(KeyCode k)
    {
        string n = k.ToString();
        if (n.StartsWith("Alpha")) n = "Digit" + n.Substring(5);
        else if (n == "Return") n = "Enter";
        Key key;
        if (!System.Enum.TryParse<Key>(n, out key)) return Key.None;
        return key;
    }
    public static bool GetKey(KeyCode k) { var kb = Keyboard.current; var key = Map(k); return kb != null && key != Key.None && kb[key].isPressed; }
    public static bool GetKeyDown(KeyCode k) { var kb = Keyboard.current; var key = Map(k); return kb != null && key != Key.None && kb[key].wasPressedThisFrame; }
    public static Vector2 MousePosition { get { return Mouse.current != null ? Mouse.current.position.ReadValue() : Vector2.zero; } }
    public static bool MouseButton(int b)
    {
        var m = Mouse.current; if (m == null) return false;
        return b == 0 ? m.leftButton.isPressed : b == 1 ? m.rightButton.isPressed : m.middleButton.isPressed;
    }
    public static bool MouseButtonDown(int b)
    {
        var m = Mouse.current; if (m == null) return false;
        return b == 0 ? m.leftButton.wasPressedThisFrame : b == 1 ? m.rightButton.wasPressedThisFrame : m.middleButton.wasPressedThisFrame;
    }
    public static Vector2 MouseDelta { get { return Mouse.current != null ? Mouse.current.delta.ReadValue() * 0.1f : Vector2.zero; } }
#else
    public static bool GetKey(KeyCode k) { return Input.GetKey(k); }
    public static bool GetKeyDown(KeyCode k) { return Input.GetKeyDown(k); }
    public static Vector2 MousePosition { get { return Input.mousePosition; } }
    public static bool MouseButton(int b) { return Input.GetMouseButton(b); }
    public static bool MouseButtonDown(int b) { return Input.GetMouseButtonDown(b); }
    public static Vector2 MouseDelta { get { return new Vector2(Input.GetAxisRaw("Mouse X"), Input.GetAxisRaw("Mouse Y")); } }
#endif

    /// <summary>-1..1 from A/D or Left/Right arrows (same as Input.GetAxis("Horizontal")).</summary>
    public static float Horizontal()
    {
        float v = 0f;
        if (GetKey(KeyCode.D) || GetKey(KeyCode.RightArrow)) v += 1f;
        if (GetKey(KeyCode.A) || GetKey(KeyCode.LeftArrow)) v -= 1f;
        return v;
    }
    /// <summary>-1..1 from W/S or Up/Down arrows (same as Input.GetAxis("Vertical")).</summary>
    public static float Vertical()
    {
        float v = 0f;
        if (GetKey(KeyCode.W) || GetKey(KeyCode.UpArrow)) v += 1f;
        if (GetKey(KeyCode.S) || GetKey(KeyCode.DownArrow)) v -= 1f;
        return v;
    }
}
