using UnityEngine;

/// <summary>Editor-style fly camera: hold Right Mouse to look, WASD to move, Q/E down/up.</summary>
public class FreeCam : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float lookSensitivity = 3f;
    public bool needRightMouse = true;
    public bool allowMove = true;
    float yaw, pitch;

    void Start()
    {
        var e = transform.eulerAngles;
        yaw = e.y; pitch = e.x > 180f ? e.x - 360f : e.x;
    }

    void Update()
    {
        if (!needRightMouse || InputCompat.MouseButton(1))
        {
            Vector2 d = InputCompat.MouseDelta * lookSensitivity;
            yaw += d.x; pitch = Mathf.Clamp(pitch - d.y, -89f, 89f);
            transform.rotation = Quaternion.Euler(pitch, yaw, 0f);
        }
        if (!allowMove) return;
        float up = (InputCompat.GetKey(KeyCode.E) ? 1f : 0f) - (InputCompat.GetKey(KeyCode.Q) ? 1f : 0f);
        Vector3 m = transform.right * InputCompat.Horizontal() + transform.forward * InputCompat.Vertical() + Vector3.up * up;
        float s = moveSpeed * (InputCompat.GetKey(KeyCode.LeftShift) ? 2.5f : 1f);
        transform.position += m * s * Time.deltaTime;
    }
}
