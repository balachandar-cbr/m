using UnityEngine;

/// <summary>Simple walking first-person controller (WASD + mouse). Esc frees the cursor, click locks it again.</summary>
[RequireComponent(typeof(CharacterController))]
public class FirstPersonController : MonoBehaviour
{
    public Camera cam;
    public float speed = 4f;
    public float sprintMultiplier = 1.8f;
    public float lookSensitivity = 3f;
    public float gravity = -20f;
    public bool zeroG;                 // true = fly in the camera direction (used in Exercise 11)
    public bool lockCursorOnStart = true;

    CharacterController cc;
    float pitch, vy;

    void Start()
    {
        cc = GetComponent<CharacterController>();
        if (cam == null) cam = GetComponentInChildren<Camera>();
        if (lockCursorOnStart) SetCursor(true);
    }

    public static void SetCursor(bool locked)
    {
        Cursor.lockState = locked ? CursorLockMode.Locked : CursorLockMode.None;
        Cursor.visible = !locked;
    }

    public void Teleport(Vector3 pos)
    {
        if (cc == null) cc = GetComponent<CharacterController>();
        cc.enabled = false; transform.position = pos; cc.enabled = true; vy = 0f;
    }
    public void SetYaw(float yaw) { var e = transform.eulerAngles; e.y = yaw; transform.eulerAngles = e; }

    void Update()
    {
        if (InputCompat.GetKeyDown(KeyCode.Escape)) SetCursor(false);
        else if (InputCompat.MouseButtonDown(0) && Cursor.lockState != CursorLockMode.Locked) SetCursor(true);

        if (Cursor.lockState == CursorLockMode.Locked)
        {
            Vector2 d = InputCompat.MouseDelta * lookSensitivity;
            transform.Rotate(0f, d.x, 0f);
            pitch = Mathf.Clamp(pitch - d.y, -85f, 85f);
            if (cam != null) cam.transform.localRotation = Quaternion.Euler(pitch, 0f, 0f);
        }

        float h = InputCompat.Horizontal(), v = InputCompat.Vertical();
        float s = speed * (InputCompat.GetKey(KeyCode.LeftShift) ? sprintMultiplier : 1f);
        Vector3 move;
        if (zeroG && cam != null)
        {
            move = (cam.transform.forward * v + cam.transform.right * h) * s;
        }
        else
        {
            move = (transform.right * h + transform.forward * v) * s;
            vy = cc.isGrounded ? -2f : vy + gravity * Time.deltaTime;
            move.y = vy;
        }
        cc.Move(move * Time.deltaTime);
    }
}
