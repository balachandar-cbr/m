using UnityEngine;

/// <summary>
/// Press Play in ANY scene (even an empty one) and the exercise builds itself.
/// If you already ran  AR-VR Lab > Build Exercise Scene  and saved the scene, nothing is built twice.
/// </summary>
public static class Bootstrap
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Run()
    {
        if (!ARVR.HasRoot()) ExerciseBuilder.Build();
    }
}
