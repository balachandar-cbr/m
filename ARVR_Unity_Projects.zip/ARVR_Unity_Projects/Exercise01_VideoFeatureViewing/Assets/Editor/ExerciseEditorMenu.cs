#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class ExerciseEditorMenu
{
    [MenuItem("AR-VR Lab/Build Exercise Scene (saves to Assets/Scenes)")]
    static void BuildScene()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        ExerciseBuilder.Build();
        if (!AssetDatabase.IsValidFolder("Assets/Scenes")) AssetDatabase.CreateFolder("Assets", "Scenes");
        string path = "Assets/Scenes/" + ExerciseBuilder.Title.Replace(' ', '_') + ".unity";
        EditorSceneManager.SaveScene(scene, path);
        AssetDatabase.SaveAssets();
        Debug.Log("Scene built and saved: " + path + "  -> press Play.");
    }
}
#endif
