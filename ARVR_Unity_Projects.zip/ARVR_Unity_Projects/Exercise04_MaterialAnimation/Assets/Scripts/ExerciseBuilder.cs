using UnityEngine;

public static class ExerciseBuilder
{
    public const string Title = "Exercise04 Material Animation";

    static Gradient Grad(params Color[] cols)
    {
        var g = new Gradient();
        var ck = new GradientColorKey[cols.Length];
        for (int i = 0; i < cols.Length; i++) ck[i] = new GradientColorKey(cols[i], i / (float)(cols.Length - 1));
        g.SetKeys(ck, new[] { new GradientAlphaKey(1, 0), new GradientAlphaKey(1, 1) });
        return g;
    }

    public static void Build()
    {
        ARVR.ClearDefaults();
        ARVR.MakeSun(1f);
        var cam = ARVR.MakeCamera(new Vector3(0, 2f, -6.5f), new Vector3(10, 0, 0));
        cam.gameObject.AddComponent<FreeCam>();
        ARVR.Prim(PrimitiveType.Plane, "Ground", Vector3.zero, new Vector3(2, 1, 2), ARVR.Mat("Ex4_Ground", new Color(0.4f, 0.38f, 0.36f), 0f, 0.1f));

        // Sphere: colour + emission animation  (red -> yellow -> cyan -> blue -> red)
        var sphere = ARVR.Prim(PrimitiveType.Sphere, "AnimatedSphere", new Vector3(0, 1, 0), Vector3.one * 1.4f, ARVR.Mat("AnimatedMaterial", Color.red, 0.1f, 0.7f));
        var a1 = sphere.AddComponent<MaterialAnimator>();
        a1.animateColor = true; a1.animateEmission = true;
        a1.colorGradient = Grad(Color.red, Color.yellow, Color.cyan, Color.blue, Color.red);
        a1.duration = 4f;

        // Cylinder: emission pulse only (ping-pong)
        var cyl = ARVR.Prim(PrimitiveType.Cylinder, "PulseCylinder", new Vector3(-2.6f, 1, 0), new Vector3(1, 1, 1), ARVR.Mat("PulseMaterial", Color.green, 0f, 0.5f));
        var a2 = cyl.AddComponent<MaterialAnimator>();
        a2.animateColor = false; a2.animateEmission = true; a2.pingPong = true; a2.duration = 1.5f; a2.emissionIntensity = 2.5f;

        // Cube: scrolling texture offset (conveyor look)
        var cube = ARVR.Prim(PrimitiveType.Cube, "ScrollCube", new Vector3(2.6f, 1, 0), Vector3.one * 1.4f, ARVR.Mat("ScrollMaterial", Color.white, 0f, 0.3f));
        var a3 = cube.AddComponent<MaterialAnimator>();
        a3.animateColor = false; a3.animateEmission = false; a3.scrollTexture = true; a3.scrollSpeed = new Vector2(0.5f, 0f);

        new GameObject("MaterialAnimationHud").AddComponent<MaterialAnimationHud>().transform.SetParent(ARVR.Root(), false);
    }
}
