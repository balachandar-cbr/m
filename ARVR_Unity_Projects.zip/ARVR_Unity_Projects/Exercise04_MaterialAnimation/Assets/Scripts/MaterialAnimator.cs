using UnityEngine;

/// <summary>Animates material properties over time: Colour, Emission and Texture Offset (keyframed by Gradient / AnimationCurve).</summary>
public class MaterialAnimator : MonoBehaviour
{
    public static float globalSpeed = 1f;
    public static bool paused;

    public bool animateColor = true;
    public bool animateEmission = true;
    public bool scrollTexture = false;
    public bool pingPong = false;
    public float duration = 4f;
    public float emissionIntensity = 2f;
    public Vector2 scrollSpeed = new Vector2(0.5f, 0f);
    public Gradient colorGradient;
    public AnimationCurve emissionCurve = new AnimationCurve(new Keyframe(0, 0.1f), new Keyframe(0.5f, 1f), new Keyframe(1, 0.1f));

    Material mat;
    Color baseColor;
    float clock;

    void Start()
    {
        mat = GetComponent<Renderer>().material;      // runtime instance of the material
        baseColor = mat.color;
        if (animateEmission) mat.EnableKeyword("_EMISSION");
        if (scrollTexture) mat.mainTexture = MakeChecker();
    }

    void Update()
    {
        if (mat == null) return;
        if (!paused) clock += Time.deltaTime * globalSpeed;
        float t = pingPong ? Mathf.PingPong(clock / duration, 1f) : Mathf.Repeat(clock / duration, 1f);

        Color c = baseColor;
        if (animateColor && colorGradient != null) { c = colorGradient.Evaluate(t); mat.color = c; }
        if (animateEmission) ARVR.SetEmission(mat, c * emissionCurve.Evaluate(t) * emissionIntensity);
        if (scrollTexture) mat.mainTextureOffset = new Vector2(clock * scrollSpeed.x, clock * scrollSpeed.y);
    }

    static Texture2D MakeChecker()
    {
        var t = new Texture2D(64, 64, TextureFormat.RGBA32, true);
        for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++)
            t.SetPixel(x, y, ((x / 8 + y / 8) % 2 == 0) ? new Color(0.9f, 0.9f, 0.9f) : new Color(0.15f, 0.35f, 0.9f));
        t.wrapMode = TextureWrapMode.Repeat; t.filterMode = FilterMode.Point; t.Apply();
        return t;
    }
}

public class MaterialAnimationHud : MonoBehaviour
{
    void Update()
    {
        if (InputCompat.GetKeyDown(KeyCode.Space)) MaterialAnimator.paused = !MaterialAnimator.paused;
        if (InputCompat.GetKeyDown(KeyCode.UpArrow)) MaterialAnimator.globalSpeed = Mathf.Min(5f, MaterialAnimator.globalSpeed + 0.25f);
        if (InputCompat.GetKeyDown(KeyCode.DownArrow)) MaterialAnimator.globalSpeed = Mathf.Max(0.25f, MaterialAnimator.globalSpeed - 0.25f);
    }
    void OnGUI()
    {
        ARVR.Hud("MATERIAL ANIMATION\nSphere: colour + emission   Cylinder: emission pulse   Cube: texture offset scroll\n[Space] " + (MaterialAnimator.paused ? "resume" : "pause") + "   [Up/Down] speed = " + MaterialAnimator.globalSpeed.ToString("0.00") + "x   Hold right mouse + WASD to fly", 14);
    }
}
