#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

/// <summary>
/// Optional: creates a REAL keyframed AnimationClip (like the Animation window in the lab record)
/// for the selected object's material colour, adds an Animator and switches the script version off.
/// </summary>
public static class KeyframeClipMenu
{
    [MenuItem("AR-VR Lab/Ex4 - Create keyframe AnimationClip on selected object")]
    static void Create()
    {
        var go = Selection.activeGameObject;
        if (go == null || go.GetComponent<Renderer>() == null) { Debug.LogWarning("Select the sphere (AnimatedSphere) in the Hierarchy first."); return; }
        string prop = go.GetComponent<Renderer>().sharedMaterial.HasProperty("_BaseColor") ? "_BaseColor" : "_Color";

        var clip = new AnimationClip { frameRate = 30 };
        float[] t = { 0, 1, 2, 3, 4 };
        float[] r = { 1, 1, 0, 0, 1 }, g = { 0, 1, 1, 0, 0 }, b = { 0, 0, 1, 1, 0 };
        string[] ch = { "r", "g", "b" };
        float[][] vals = { r, g, b };
        for (int c = 0; c < 3; c++)
        {
            var keys = new Keyframe[t.Length];
            for (int i = 0; i < t.Length; i++) keys[i] = new Keyframe(t[i], vals[c][i]);
            AnimationUtility.SetEditorCurve(clip, EditorCurveBinding.FloatCurve("", typeof(MeshRenderer), "material." + prop + "." + ch[c]), new AnimationCurve(keys));
        }
        var a = new AnimationCurve(new Keyframe(0, 1), new Keyframe(4, 1));
        AnimationUtility.SetEditorCurve(clip, EditorCurveBinding.FloatCurve("", typeof(MeshRenderer), "material." + prop + ".a"), a);
        var s = AnimationUtility.GetAnimationClipSettings(clip); s.loopTime = true; AnimationUtility.SetAnimationClipSettings(clip, s);

        if (!AssetDatabase.IsValidFolder("Assets/Animations")) AssetDatabase.CreateFolder("Assets", "Animations");
        string clipPath = AssetDatabase.GenerateUniqueAssetPath("Assets/Animations/MaterialColour.anim");
        AssetDatabase.CreateAsset(clip, clipPath);
        var ctrl = AnimatorController.CreateAnimatorControllerAtPathWithClip(AssetDatabase.GenerateUniqueAssetPath("Assets/Animations/MaterialColour.controller"), clip);
        var anim = go.GetComponent<Animator>(); if (anim == null) anim = go.AddComponent<Animator>();
        anim.runtimeAnimatorController = ctrl;
        var ma = go.GetComponent<MaterialAnimator>(); if (ma != null) ma.enabled = false;
        AssetDatabase.SaveAssets();
        Debug.Log("Keyframe clip created: " + clipPath + " (open Window > Animation > Animation to edit the keyframes).");
    }
}
#endif
