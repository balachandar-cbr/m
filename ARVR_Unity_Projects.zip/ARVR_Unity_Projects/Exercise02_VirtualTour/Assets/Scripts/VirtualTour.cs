using System.Collections.Generic;
using UnityEngine;

public class InfoPoint : MonoBehaviour
{
    public string title;
    [TextArea] public string body;
    [HideInInspector] public Vector3 basePos;
    [HideInInspector] public float phase;
    void Start() { basePos = transform.position; phase = Random.value * 6f; }
}

/// <summary>Controls the tour: info panels near markers, visited counter, teleport between stops (1-3).</summary>
public class VirtualTour : MonoBehaviour
{
    public FirstPersonController player;
    public InfoPoint[] points;
    public Transform[] stops;
    public float showDistance = 3f;

    HashSet<InfoPoint> visited = new HashSet<InfoPoint>();
    InfoPoint near;

    void Update()
    {
        if (player == null) return;
        near = null; float best = showDistance;
        Vector3 eye = player.transform.position + Vector3.up * 1.4f;
        foreach (var p in points)
        {
            if (p == null) continue;
            p.transform.position = p.basePos + Vector3.up * Mathf.Sin(Time.time * 2f + p.phase) * 0.08f;
            float d = Vector3.Distance(eye, p.transform.position);
            if (d < best) { best = d; near = p; }
        }
        if (near != null) visited.Add(near);

        for (int i = 0; i < stops.Length; i++)
            if (InputCompat.GetKeyDown(KeyCode.Alpha1 + i)) { player.Teleport(stops[i].position); player.SetYaw(0f); }
    }

    void OnGUI()
    {
        float k = ARVR.GuiScale();
        ARVR.Hud("VIRTUAL TOUR\nWASD move | Mouse look | Shift run | Esc free cursor\nKeys 1 / 2 / 3 : jump to Lobby / Gallery / Library\nInformation points visited: " + visited.Count + " / " + (points != null ? points.Length : 0), 14);
        if (near != null)
        {
            var r = new Rect(Screen.width * 0.5f - 260 * k, Screen.height - 150 * k, 520 * k, 130 * k);
            GUI.Box(r, "");
            ARVR.Text(new Rect(r.x + 14 * k, r.y + 8 * k, r.width - 28 * k, 30 * k), near.title, 20, TextAnchor.UpperLeft, true);
            ARVR.Text(new Rect(r.x + 14 * k, r.y + 40 * k, r.width - 28 * k, 90 * k), near.body, 15);
        }
        ARVR.Text(new Rect(Screen.width / 2 - 10, Screen.height / 2 - 12, 20, 24), "+", 18, TextAnchor.MiddleCenter);
    }
}
