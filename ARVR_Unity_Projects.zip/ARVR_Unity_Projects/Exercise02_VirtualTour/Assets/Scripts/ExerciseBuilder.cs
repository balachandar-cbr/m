using UnityEngine;

public static class ExerciseBuilder
{
    public const string Title = "Exercise02 Virtual Tour";
    static Material wallM, woodM;

    static void Wall(Vector3 c, Vector3 s) { ARVR.Prim(PrimitiveType.Cube, "Wall", c, s, wallM); }
    static void Divider(float z)
    {
        Wall(new Vector3(-2.6f, 1.5f, z), new Vector3(2.8f, 3f, 0.2f));
        Wall(new Vector3(2.6f, 1.5f, z), new Vector3(2.8f, 3f, 0.2f));
        Wall(new Vector3(0f, 2.65f, z), new Vector3(2.4f, 0.7f, 0.2f));   // lintel above the doorway
    }
    static InfoPoint Info(string name, Vector3 pos, string title, string body, Material m)
    {
        var g = ARVR.Prim(PrimitiveType.Sphere, name, pos, Vector3.one * 0.35f, m, null, false);
        var ip = g.AddComponent<InfoPoint>();
        ip.title = title; ip.body = body;
        return ip;
    }

    public static void Build()
    {
        ARVR.ClearDefaults();
        wallM = ARVR.Mat("Ex2_Wall", new Color(0.93f, 0.92f, 0.88f), 0f, 0.2f);
        woodM = ARVR.Mat("Ex2_Wood", new Color(0.45f, 0.30f, 0.18f), 0f, 0.45f);
        var carpet = ARVR.Mat("Ex2_Carpet", new Color(0.25f, 0.30f, 0.42f), 0f, 0.1f);
        var marble = ARVR.Mat("Ex2_Marble", new Color(0.80f, 0.80f, 0.82f), 0f, 0.8f);
        var sofaM = ARVR.Mat("Ex2_Sofa", new Color(0.35f, 0.20f, 0.18f), 0f, 0.2f);
        var green = ARVR.Mat("Ex2_Plant", new Color(0.15f, 0.55f, 0.2f));
        var glow = ARVR.Emissive("Ex2_InfoGlow", new Color(0.2f, 0.9f, 1f), 2.5f);

        // ---- building shell: 3 rooms (Lobby z -4..4, Gallery 4..12, Library 12..20), each 8 m wide
        Wall(new Vector3(-4f, 1.5f, 8f), new Vector3(0.2f, 3f, 24f));
        Wall(new Vector3(4f, 1.5f, 8f), new Vector3(0.2f, 3f, 24f));
        Wall(new Vector3(0f, 1.5f, -4f), new Vector3(8.2f, 3f, 0.2f));
        Wall(new Vector3(0f, 1.5f, 20f), new Vector3(8.2f, 3f, 0.2f));
        Divider(4f); Divider(12f);
        ARVR.Prim(PrimitiveType.Cube, "Ceiling", new Vector3(0, 3.05f, 8f), new Vector3(8.4f, 0.1f, 24.4f), wallM);
        ARVR.Prim(PrimitiveType.Cube, "Floor_Lobby", new Vector3(0, -0.05f, 0f), new Vector3(8f, 0.1f, 8f), marble);
        ARVR.Prim(PrimitiveType.Cube, "Floor_Gallery", new Vector3(0, -0.05f, 8f), new Vector3(8f, 0.1f, 8f), woodM);
        ARVR.Prim(PrimitiveType.Cube, "Floor_Library", new Vector3(0, -0.05f, 16f), new Vector3(8f, 0.1f, 8f), carpet);

        // ---- lights
        ARVR.MakePointLight("Light_Lobby", new Vector3(0, 2.6f, 0), new Color(1f, 0.95f, 0.85f), 1.3f, 12f);
        ARVR.MakePointLight("Light_Gallery", new Vector3(0, 2.6f, 8), new Color(1f, 0.92f, 0.8f), 1.3f, 12f);
        ARVR.MakePointLight("Light_Library", new Vector3(0, 2.6f, 16), new Color(1f, 0.85f, 0.65f), 1.3f, 12f);

        // ---- Lobby furniture
        ARVR.Prim(PrimitiveType.Cube, "ReceptionDesk", new Vector3(0, 0.5f, 2.5f), new Vector3(3f, 1f, 0.8f), woodM);
        ARVR.Prim(PrimitiveType.Cube, "SofaSeat", new Vector3(-2.8f, 0.25f, -1f), new Vector3(1.8f, 0.5f, 0.9f), sofaM);
        ARVR.Prim(PrimitiveType.Cube, "SofaBack", new Vector3(-2.8f, 0.75f, -1.35f), new Vector3(1.8f, 0.6f, 0.2f), sofaM);
        ARVR.Prim(PrimitiveType.Cylinder, "PlantPot", new Vector3(3f, 0.3f, -3f), new Vector3(0.5f, 0.3f, 0.5f), woodM);
        ARVR.Prim(PrimitiveType.Sphere, "PlantLeaves", new Vector3(3f, 1f, -3f), Vector3.one * 0.9f, green);

        // ---- Gallery: pedestals with art, paintings on walls
        Color[] art = { new Color(0.9f, 0.3f, 0.3f), new Color(0.3f, 0.6f, 0.95f), new Color(0.95f, 0.8f, 0.2f), new Color(0.5f, 0.9f, 0.5f) };
        float[] gx = { -2.2f, 2.2f, -2.2f, 2.2f }; float[] gz = { 6f, 6f, 10f, 10f };
        for (int i = 0; i < 4; i++)
        {
            ARVR.Prim(PrimitiveType.Cylinder, "Pedestal" + i, new Vector3(gx[i], 0.5f, gz[i]), new Vector3(0.8f, 0.5f, 0.8f), marble);
            ARVR.Prim(PrimitiveType.Sphere, "Artwork" + i, new Vector3(gx[i], 1.35f, gz[i]), Vector3.one * 0.6f, ARVR.Mat("Ex2_Art" + i, art[i], 0.6f, 0.8f));
        }
        for (int i = 0; i < 2; i++)
        {
            ARVR.Prim(PrimitiveType.Cube, "PaintingL" + i, new Vector3(-3.85f, 1.7f, 6f + i * 4f), new Vector3(0.05f, 1.3f, 2f), ARVR.Mat("Ex2_PaintL" + i, art[i + 1]));
            ARVR.Prim(PrimitiveType.Cube, "PaintingR" + i, new Vector3(3.85f, 1.7f, 6f + i * 4f), new Vector3(0.05f, 1.3f, 2f), ARVR.Mat("Ex2_PaintR" + i, art[i]));
        }

        // ---- Library: shelves with books, reading table + chairs
        for (int s = -1; s <= 1; s += 2)
        {
            ARVR.Prim(PrimitiveType.Cube, "Shelf", new Vector3(3.6f * s, 1.2f, 16f), new Vector3(0.5f, 2.4f, 6f), woodM);
            for (int r = 0; r < 4; r++)
                for (int b = 0; b < 6; b++)
                {
                    var col = Color.HSVToRGB((r * 0.17f + b * 0.11f) % 1f, 0.6f, 0.85f);
                    ARVR.Prim(PrimitiveType.Cube, "Book", new Vector3(3.33f * s, 0.4f + r * 0.55f, 14f + b * 0.9f), new Vector3(0.08f, 0.35f, 0.5f), ARVR.Mat("Ex2_Book" + r + b, col));
                }
        }
        ARVR.Prim(PrimitiveType.Cube, "TableTop", new Vector3(0, 0.78f, 16f), new Vector3(2.4f, 0.08f, 1.2f), woodM);
        ARVR.Prim(PrimitiveType.Cylinder, "TableLeg", new Vector3(0, 0.38f, 16f), new Vector3(0.3f, 0.38f, 0.3f), woodM);
        for (int i = 0; i < 4; i++)
            ARVR.Prim(PrimitiveType.Cube, "Chair" + i, new Vector3(i % 2 == 0 ? -0.7f : 0.7f, 0.25f, i < 2 ? 15.2f : 16.8f), new Vector3(0.45f, 0.5f, 0.45f), sofaM);

        // ---- information points
        var p1 = Info("Info_Lobby", new Vector3(0f, 1.8f, 1.2f), "Welcome Lobby", "Start of the virtual tour. Walk through the doorway to the north to enter the Gallery.", glow);
        var p2 = Info("Info_Lounge", new Vector3(-2.8f, 1.4f, -1f), "Lounge Area", "Visitors relax here before the tour. Information points glow cyan wherever there is something to learn.", glow);
        var p3 = Info("Info_Gallery", new Vector3(0f, 1.6f, 8f), "Art Gallery", "Four sculptures stand on marble pedestals and paintings hang on the side walls.", glow);
        var p4 = Info("Info_Library", new Vector3(0f, 1.6f, 17.8f), "Library", "Bookshelves line both walls with a reading table in the middle. This is the last stop of the tour.", glow);

        // ---- tour stops (teleport points: keys 1,2,3)
        var stops = new Transform[3];
        string[] sn = { "Stop1_Lobby", "Stop2_Gallery", "Stop3_Library" };
        float[] sz = { -2.5f, 5.5f, 13.5f };
        for (int i = 0; i < 3; i++)
        {
            var g = new GameObject(sn[i]); g.transform.SetParent(ARVR.Root(), false); g.transform.position = new Vector3(0, 0.1f, sz[i]); stops[i] = g.transform;
        }

        // ---- player (CharacterController + camera at eye height)
        var pl = new GameObject("Player");
        pl.transform.SetParent(ARVR.Root(), false);
        pl.transform.position = stops[0].position;
        var cc = pl.AddComponent<CharacterController>();
        cc.height = 1.8f; cc.radius = 0.3f; cc.center = new Vector3(0, 0.9f, 0);
        var cam = ARVR.MakeCamera(new Vector3(0, 1.6f, 0), Vector3.zero, pl.transform);
        var fpc = pl.AddComponent<FirstPersonController>();
        fpc.cam = cam; fpc.speed = 3.5f;

        var tour = new GameObject("TourManager").AddComponent<VirtualTour>();
        tour.transform.SetParent(ARVR.Root(), false);
        tour.player = fpc; tour.points = new[] { p1, p2, p3, p4 }; tour.stops = stops;
    }
}
