// Draws a render texture in SCREEN SPACE, so the planet seen through the portal has correct parallax
// (it behaves like a real window into another place, not a flat picture).
Shader "ARVR/PortalScreen"
{
    Properties { _MainTex ("Portal view (RenderTexture)", 2D) = "black" {} }
    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Geometry" }
        Cull Off
        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"
            sampler2D _MainTex;
            struct v2f { float4 pos : SV_POSITION; float4 sp : TEXCOORD0; };
            v2f vert (appdata_base v)
            {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.sp = ComputeScreenPos(o.pos);
                return o;
            }
            fixed4 frag (v2f i) : SV_Target
            {
                float2 uv = i.sp.xy / i.sp.w;
                return tex2D(_MainTex, uv);
            }
            ENDCG
        }
    }
}
