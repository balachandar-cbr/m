using UnityEngine;

public static class ExerciseBuilder
{
    public const string Title = "Exercise11 Portal Planets";

    public static void Build()
    {
        ARVR.ClearDefaults();
        ARVR.MakeSun(1f);

        // ---- the "hall" the user stands in
        ARVR.Prim(PrimitiveType.Cylinder, "HallFloor", new Vector3(0, -0.05f, 0), new Vector3(30, 0.05f, 30), ARVR.Mat("Ex11_Floor", new Color(0.08f, 0.09f, 0.12f), 0.6f, 0.8f));

        var pl = new GameObject("Player");
        pl.transform.SetParent(ARVR.Root(), false);
        pl.transform.position = new Vector3(0, 0.05f, 0);
        var cc = pl.AddComponent<CharacterController>();
        cc.height = 1.8f; cc.radius = 0.3f; cc.center = new Vector3(0, 0.9f, 0);
        var cam = ARVR.MakeCamera(new Vector3(0, 1.6f, 0), Vector3.zero, pl.transform, true, new Color(0.02f, 0.03f, 0.06f));
        var fpc = pl.AddComponent<FirstPersonController>(); fpc.cam = cam; fpc.speed = 4f;

        var start = new GameObject("HallStart"); start.transform.SetParent(ARVR.Root(), false); start.transform.position = new Vector3(0, 0.05f, 0);

        var mgr = new GameObject("PortalPlanets").AddComponent<PortalPlanets>();
        mgr.transform.SetParent(ARVR.Root(), false);
        mgr.player = fpc; mgr.hallStart = start.transform;

        // ---- three portals on an arc: Mars, Earth, Saturn
        PlanetKind[] kinds = { PlanetKind.Mars, PlanetKind.Earth, PlanetKind.Saturn };
        string[] names = { "Mars", "Earth", "Saturn" };
        string[] facts =
        {
            "Mars - the 4th planet from the Sun. Diameter about 6,779 km, a day lasts about 24.6 hours, 2 small moons (Phobos and Deimos). Its red colour comes from iron oxide dust.",
            "Earth - the 3rd planet from the Sun. Diameter about 12,742 km, 1 moon, about 71% of the surface is covered by liquid water.",
            "Saturn - the 6th planet from the Sun. Mean diameter about 116,460 km, famous for its ice-and-rock rings, a gas giant with a very low density."
        };
        float[] angles = { -50f, 0f, 50f };
        var portals = new PortalView[3];

        for (int i = 0; i < 3; i++)
        {
            Vector3 dir = Quaternion.Euler(0, angles[i], 0) * Vector3.forward;
            var root = new GameObject("Portal_" + names[i]);
            root.transform.SetParent(ARVR.Root(), false);
            root.transform.position = dir * 10f + Vector3.up * 2.4f;
            root.transform.rotation = Quaternion.LookRotation(dir);            // +Z points away from the viewer

            // frame (ring of glowing blocks, rotates slowly) + stand
            var frame = new GameObject("Frame"); frame.transform.SetParent(root.transform, false);
            var glow = ARVR.Emissive("Ex11_PortalGlow" + i, new Color(0.2f, 0.85f, 1f), 2.5f);
            for (int b = 0; b < 32; b++)
            {
                float a = b / 32f * Mathf.PI * 2f;
                var blk = ARVR.Prim(PrimitiveType.Cube, "Seg" + b, new Vector3(Mathf.Cos(a), Mathf.Sin(a), 0) * 2.2f, new Vector3(0.38f, 0.38f, 0.55f), glow, frame.transform, false);
                blk.transform.localRotation = Quaternion.Euler(0, 0, a * Mathf.Rad2Deg);
            }
            frame.AddComponent<Spin>().axis = Vector3.forward;
            ARVR.Prim(PrimitiveType.Cube, "Stand", new Vector3(0, -2.2f, 0), new Vector3(3.6f, 0.4f, 1.4f), ARVR.Mat("Ex11_Stand", new Color(0.15f, 0.16f, 0.2f), 0.7f, 0.6f), root.transform);
            ARVR.MakePointLight("PortalLight", new Vector3(0, 0, -1.5f), new Color(0.3f, 0.85f, 1f), 1.5f, 9f, root.transform);

            // portal surface (shows what the remote camera sees)
            var surf = new GameObject("Surface"); surf.transform.SetParent(root.transform, false);
            var mf = surf.AddComponent<MeshFilter>();
            var mr = surf.AddComponent<MeshRenderer>();
            mr.sharedMaterial = ARVR.FromShader("Ex11_PortalScreen" + i, "ARVR/PortalScreen", "Unlit/Texture", "Sprites/Default");

            // remote space far away: anchor oriented like the portal so directions match
            var anchor = new GameObject("RemoteSpace_" + names[i]);
            anchor.transform.SetParent(ARVR.Root(), false);
            anchor.transform.position = new Vector3(300f * (i + 1), 600f, 0f);
            anchor.transform.rotation = root.transform.rotation;

            var pivot = new GameObject("PlanetPivot"); pivot.transform.SetParent(anchor.transform, false);
            pivot.transform.localPosition = new Vector3(0, 0, 9f);
            pivot.transform.localRotation = Quaternion.Euler(0, 0, kinds[i] == PlanetKind.Saturn ? 22f : 15f);
            var planet = ARVR.Prim(PrimitiveType.Sphere, names[i], Vector3.zero, Vector3.one * 6f, ARVR.Mat("Ex11_Planet" + names[i], Color.white, 0f, 0.15f), pivot.transform, false);
            var pv = planet.AddComponent<PlanetVisual>(); pv.kind = kinds[i]; pv.ring = kinds[i] == PlanetKind.Saturn; pv.spinSpeed = 12f;

            var starM = ARVR.Unlit("Ex11_Star", Color.white);
            Random.InitState(7 + i);
            for (int s = 0; s < 140; s++)
                ARVR.Prim(PrimitiveType.Cube, "Star", Random.onUnitSphere * Random.Range(50f, 60f), Vector3.one * Random.Range(0.12f, 0.35f), starM, anchor.transform, false);

            var camGo = new GameObject("RemoteCamera_" + names[i]);
            camGo.transform.SetParent(ARVR.Root(), false);
            var rc = camGo.AddComponent<Camera>();
            rc.clearFlags = CameraClearFlags.SolidColor; rc.backgroundColor = Color.black; rc.depth = -10; rc.farClipPlane = 200f; rc.nearClipPlane = 0.05f;

            var pvw = root.AddComponent<PortalView>();
            pvw.remoteAnchor = anchor.transform; pvw.remoteCam = rc; pvw.surfaceFilter = mf; pvw.surfaceRenderer = mr;
            pvw.radius = 2f; pvw.planetName = names[i]; pvw.facts = facts[i]; pvw.manager = mgr;
            portals[i] = pvw;
        }
        mgr.portals = portals;
    }
}
