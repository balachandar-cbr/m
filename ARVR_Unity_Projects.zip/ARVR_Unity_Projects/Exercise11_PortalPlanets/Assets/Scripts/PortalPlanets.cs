using UnityEngine;

public enum PlanetKind { Mars, Earth, Saturn }

public class Spin : MonoBehaviour
{
    public Vector3 axis = Vector3.up;
    public float speed = 20f;
    void Update() { transform.Rotate(axis, speed * Time.deltaTime, Space.Self); }
}

/// <summary>Generates a planet texture and a ring (Saturn) at run time, and spins the planet.</summary>
public class PlanetVisual : MonoBehaviour
{
    public PlanetKind kind;
    public bool ring;
    public float spinSpeed = 12f;

    void Start()
    {
        GetComponent<Renderer>().material.mainTexture = MakeTexture(kind);
        if (ring) MakeRing();
    }
    void Update() { transform.Rotate(Vector3.up, spinSpeed * Time.deltaTime, Space.Self); }

    static float N(Vector3 p)
    {
        return (Mathf.PerlinNoise(p.x + 10f, p.y + 10f) + Mathf.PerlinNoise(p.y + 20f, p.z + 20f) + Mathf.PerlinNoise(p.z + 30f, p.x + 30f)) / 3f;
    }
    static float Fbm(Vector3 p, int oct)
    {
        float v = 0, a = 0.5f, f = 1f, sum = 0;
        for (int i = 0; i < oct; i++) { v += a * N(p * f); sum += a; f *= 2f; a *= 0.5f; }
        return v / sum;
    }

    static Texture2D MakeTexture(PlanetKind k)
    {
        const int W = 256, H = 128;
        var tex = new Texture2D(W, H, TextureFormat.RGBA32, true);
        var px = new Color[W * H];
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++)
            {
                float lon = x / (float)W * Mathf.PI * 2f, lat = (y / (float)H - 0.5f) * Mathf.PI;
                var p = new Vector3(Mathf.Cos(lat) * Mathf.Cos(lon), Mathf.Sin(lat), Mathf.Cos(lat) * Mathf.Sin(lon));
                Color c;
                if (k == PlanetKind.Earth)
                {
                    float h = Fbm(p * 2.2f, 5);
                    if (h < 0.5f) c = Color.Lerp(new Color(0.03f, 0.12f, 0.45f), new Color(0.1f, 0.38f, 0.75f), h * 2f);
                    else c = Color.Lerp(new Color(0.18f, 0.55f, 0.2f), new Color(0.5f, 0.4f, 0.25f), (h - 0.5f) * 3f);
                    if (Mathf.Abs(p.y) > 0.88f) c = Color.Lerp(c, Color.white, Mathf.Clamp01((Mathf.Abs(p.y) - 0.88f) * 12f));
                    float cl = Fbm(p * 3.5f + new Vector3(5, 5, 5), 4);
                    c = Color.Lerp(c, Color.white, Mathf.Clamp01((cl - 0.55f) * 4f) * 0.7f);
                }
                else if (k == PlanetKind.Mars)
                {
                    float h = Fbm(p * 3f, 5);
                    c = Color.Lerp(new Color(0.42f, 0.16f, 0.08f), new Color(0.82f, 0.4f, 0.2f), h);
                    if (Mathf.Abs(p.y) > 0.93f) c = Color.Lerp(c, Color.white, 0.8f);
                }
                else
                {
                    float band = Mathf.Sin(lat * 18f + Fbm(p * 2f, 3) * 3f) * 0.5f + 0.5f;
                    c = Color.Lerp(new Color(0.65f, 0.5f, 0.32f), new Color(0.88f, 0.76f, 0.54f), band);
                }
                c.a = 1f; px[y * W + x] = c;
            }
        tex.SetPixels(px); tex.wrapMode = TextureWrapMode.Repeat; tex.Apply();
        return tex;
    }

    void MakeRing()
    {
        var g = new GameObject("Ring"); g.transform.SetParent(transform, false);
        // planet radius is 0.5 in local units -> ring from 0.72 to 1.25
        const int seg = 64; float inner = 0.72f, outer = 1.25f;
        var v = new Vector3[(seg + 1) * 2]; var uv = new Vector2[v.Length]; var t = new int[seg * 12];
        for (int i = 0; i <= seg; i++)
        {
            float a = i / (float)seg * Mathf.PI * 2f; var d = new Vector3(Mathf.Cos(a), 0, Mathf.Sin(a));
            v[i * 2] = d * inner; v[i * 2 + 1] = d * outer; uv[i * 2] = new Vector2(0, i / (float)seg); uv[i * 2 + 1] = new Vector2(1, i / (float)seg);
        }
        for (int i = 0; i < seg; i++)
        {
            int a = i * 2, b = i * 2 + 1, c = i * 2 + 2, d2 = i * 2 + 3, o = i * 12;
            t[o] = a; t[o + 1] = b; t[o + 2] = c; t[o + 3] = c; t[o + 4] = b; t[o + 5] = d2;           // top
            t[o + 6] = a; t[o + 7] = c; t[o + 8] = b; t[o + 9] = c; t[o + 10] = d2; t[o + 11] = b;     // bottom
        }
        var m = new Mesh { vertices = v, uv = uv, triangles = t }; m.RecalculateNormals();
        g.AddComponent<MeshFilter>().sharedMesh = m;
        var mat = new Material(ARVR.LitShader()); mat.color = new Color(0.85f, 0.75f, 0.55f);
        g.AddComponent<MeshRenderer>().sharedMaterial = mat;
    }
}

/// <summary>
/// A window into another place: a second camera, placed in a far-away "remote space", renders the planet
/// into a RenderTexture that is drawn on the portal surface in screen space.  Walk through the portal to visit.
/// </summary>
public class PortalView : MonoBehaviour
{
    public Transform remoteAnchor;
    public Camera remoteCam;
    public Renderer surfaceRenderer;
    public MeshFilter surfaceFilter;
    public float radius = 2f;
    public string planetName;
    [TextArea] public string facts;
    public PortalPlanets manager;

    RenderTexture rt;
    Camera main;
    float lastZ; bool hasLast;

    void Start()
    {
        surfaceFilter.sharedMesh = MakeDisc(radius, 48);
        main = Camera.main;
        MakeRT();
    }

    static Mesh MakeDisc(float r, int seg)
    {
        var v = new Vector3[seg + 1]; var uv = new Vector2[seg + 1]; var t = new int[seg * 3];
        v[0] = Vector3.zero; uv[0] = new Vector2(0.5f, 0.5f);
        for (int i = 0; i < seg; i++)
        {
            float a = i / (float)seg * Mathf.PI * 2f; v[i + 1] = new Vector3(Mathf.Cos(a), Mathf.Sin(a), 0) * r;
            uv[i + 1] = new Vector2(Mathf.Cos(a) * 0.5f + 0.5f, Mathf.Sin(a) * 0.5f + 0.5f);
            t[i * 3] = 0; t[i * 3 + 1] = i + 1; t[i * 3 + 2] = (i + 1) % seg + 1;
        }
        var m = new Mesh { vertices = v, uv = uv, triangles = t }; m.RecalculateNormals(); return m;
    }

    void MakeRT()
    {
        if (rt != null) { remoteCam.targetTexture = null; rt.Release(); Destroy(rt); }
        rt = new RenderTexture(Mathf.Max(64, Screen.width), Mathf.Max(64, Screen.height), 24);
        remoteCam.targetTexture = rt;
        surfaceRenderer.material.mainTexture = rt;
    }

    public void ResetCrossing() { hasLast = false; }

    void LateUpdate()
    {
        if (main == null) { main = Camera.main; return; }
        if (Screen.width > 0 && (rt.width != Screen.width || rt.height != Screen.height)) MakeRT();

        // the remote camera has the same pose relative to the remote anchor as the viewer has relative to the portal
        Vector3 local = transform.InverseTransformPoint(main.transform.position);
        remoteCam.transform.position = remoteAnchor.TransformPoint(local);
        remoteCam.transform.rotation = remoteAnchor.rotation * (Quaternion.Inverse(transform.rotation) * main.transform.rotation);
        remoteCam.fieldOfView = main.fieldOfView;

        // walking through the disc enters the planet's space
        if (hasLast && lastZ < 0f && local.z >= 0f && new Vector2(local.x, local.y).magnitude < radius && manager != null) manager.Enter(this, local);
        lastZ = local.z; hasLast = true;
    }
}

public class PortalPlanets : MonoBehaviour
{
    public FirstPersonController player;
    public PortalView[] portals;
    public Transform hallStart;

    PortalView current, lookAt;
    bool inRemote;

    public void Enter(PortalView p, Vector3 local)
    {
        current = p; inRemote = true;
        player.zeroG = true;
        player.Teleport(p.remoteAnchor.TransformPoint(local));
        foreach (var q in portals) q.ResetCrossing();
    }

    void Return()
    {
        inRemote = false; current = null;
        player.zeroG = false;
        player.Teleport(hallStart.position); player.SetYaw(0f);
        foreach (var q in portals) q.ResetCrossing();
    }

    void Update()
    {
        if (player == null || portals == null) return;
        if (inRemote) { if (InputCompat.GetKeyDown(KeyCode.R)) Return(); return; }

        for (int i = 0; i < portals.Length && i < 9; i++)
            if (InputCompat.GetKeyDown(KeyCode.Alpha1 + i))
            {
                var t = portals[i].transform;
                player.Teleport(new Vector3(t.position.x, 0.05f, t.position.z) - t.forward * 4f);
                player.SetYaw(t.eulerAngles.y);
            }

        lookAt = null;
        Transform c = player.cam.transform;
        foreach (var p in portals)
        {
            Vector3 d = p.transform.position - c.position;
            if (d.magnitude < 22f && Vector3.Angle(c.forward, d) < 12f) { lookAt = p; break; }
        }
    }

    void OnGUI()
    {
        float k = ARVR.GuiScale();
        string help = inRemote ? "You are in space near " + (current != null ? current.planetName : "") + "  |  WASD fly in the look direction  |  R = return to the portal hall"
                               : "PORTAL PLANETS  |  WASD move, mouse look, Shift run, Esc frees cursor  |  1/2/3 jump to a portal  |  walk THROUGH a portal to visit the planet";
        ARVR.Hud(help, 14);
        PortalView shown = inRemote ? current : lookAt;
        if (shown != null)
        {
            var r = new Rect(Screen.width * 0.5f - 300 * k, Screen.height - 140 * k, 600 * k, 120 * k);
            GUI.Box(r, "");
            ARVR.Text(new Rect(r.x + 12 * k, r.y + 6 * k, r.width - 24 * k, 30 * k), shown.planetName, 22, TextAnchor.UpperLeft, true);
            ARVR.Text(new Rect(r.x + 12 * k, r.y + 38 * k, r.width - 24 * k, 80 * k), shown.facts, 14);
        }
        ARVR.Text(new Rect(Screen.width / 2 - 10, Screen.height / 2 - 12, 20, 24), "+", 18, TextAnchor.MiddleCenter);
    }
}
