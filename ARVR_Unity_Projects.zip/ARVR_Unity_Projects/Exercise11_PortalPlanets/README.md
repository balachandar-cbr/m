# Exercise 11: Implementation to Show Portal Planets
Project name in the record: **Portal Planets**

Three portals (Mars, Earth, Saturn) rendering remote planets through a second camera with a screen-space shader; walk through to visit, R to return.

**Real VR headset (optional):** Package Manager > install *XR Plug-in Management*, *OpenXR* and *XR Interaction Toolkit*; Project Settings > XR Plug-in Management > enable your device; then GameObject > XR > XR Origin and make the headset camera the Main Camera. The script logic is unchanged; without a headset everything runs with keyboard + mouse.

## How to run
1. Unity Hub > **Add > Add project from disk** > select this folder (accept the editor version prompt; any Unity 2022.3+ / Unity 6 works, Built-in or URP).
2. Wait for compile. Then either
   - open any scene (or an empty one) and press **Play** - the scene builds itself, or
   - menu **AR-VR Lab > Build Exercise Scene** to create and save `Assets/Scenes/...unity` for your screenshots, then press Play.
3. Take the output screenshot from the Game view for the record.

Source files are in `Assets/Scripts`. Works with the old Input Manager and the new Input System.
