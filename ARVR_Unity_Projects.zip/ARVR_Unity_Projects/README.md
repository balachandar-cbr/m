# AR/VR Lab (PCA25D08J) - Unity projects, Exercises 1-11
Each folder is an independent Unity project (Assets, Packages, ProjectSettings).
Open it from Unity Hub (Add project from disk), press Play. See each folder's README.

Fixes vs. the printed record: Ex7 class/file name now match (PlayerMovement); Ex8 stray typo `gameObject';` removed and the
held object's collider is disabled while carried; Ex6 does not need `Resources.Load` (uses the scene cube directly).
