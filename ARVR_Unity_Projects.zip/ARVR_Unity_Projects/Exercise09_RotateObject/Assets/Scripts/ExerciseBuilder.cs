using UnityEngine;

public static class ExerciseBuilder
{
    public const string Title = "Exercise09 Rotate Object";

    public static void Build()
    {
        ARVR.ClearDefaults();
        ARVR.MakeSun(1f);
        ARVR.MakeCamera(new Vector3(0, 0f, -4f), Vector3.zero);

        var sphere = ARVR.Prim(PrimitiveType.Sphere, "Sphere", Vector3.zero, Vector3.one * 1.6f, ARVR.Mat("Ex9_Sphere", new Color(0.55f, 0.58f, 0.65f), 0.2f, 0.6f));
        sphere.AddComponent<RotateObject>();

        // coloured markers on the sphere so the rotation is clearly visible
        Color[] cols = { Color.red, Color.yellow, Color.green, Color.cyan, Color.magenta, Color.blue };
        for (int i = 0; i < 6; i++)
        {
            float a = i * 60f * Mathf.Deg2Rad;
            var m = ARVR.Prim(PrimitiveType.Cube, "Marker" + i, new Vector3(Mathf.Sin(a) * 0.5f, 0f, Mathf.Cos(a) * 0.5f), Vector3.one * 0.12f, ARVR.Mat("Ex9_Marker" + i, cols[i]), sphere.transform);
            m.transform.localRotation = Quaternion.Euler(0, i * 60f, 0);
        }
        ARVR.Prim(PrimitiveType.Cube, "TopMarker", new Vector3(0f, 0.5f, 0f), new Vector3(0.2f, 0.12f, 0.2f), ARVR.Mat("Ex9_Top", Color.white), sphere.transform);
    }
}
