using UnityEngine;

/// <summary>Q rotates the object left, E rotates it right, around its own vertical axis.</summary>
public class RotateObject : MonoBehaviour
{
    public float rotationSpeed = 100f;

    void Update()
    {
        if (InputCompat.GetKey(KeyCode.Q)) transform.Rotate(Vector3.up * -rotationSpeed * Time.deltaTime);
        if (InputCompat.GetKey(KeyCode.E)) transform.Rotate(Vector3.up * rotationSpeed * Time.deltaTime);
    }

    void OnGUI() { ARVR.Hud("Hold  Q  : rotate left\nHold  E  : rotate right", 16); }
}
