using UnityEngine;

public class AudioVisualDemo : MonoBehaviour
{
    public AudioSource audioSrc;
    public Light pointLight;
    public ParticleSystem particles;
    public Transform orbitTarget;
    public GameObject lampBulb;
    public AudioClip customClip;          // optional: drop your own .mp3/.wav here

    bool orbit, fog;
    float angle;

    void Start()
    {
        audioSrc.clip = customClip != null ? customClip : MakeChime();
        audioSrc.Play();
        RenderSettings.fog = false;
    }

    void Update()
    {
        if (InputCompat.GetKeyDown(KeyCode.Alpha1)) { if (audioSrc.isPlaying) audioSrc.Pause(); else audioSrc.UnPause(); }
        if (InputCompat.GetKeyDown(KeyCode.Alpha2)) { pointLight.enabled = !pointLight.enabled; lampBulb.SetActive(pointLight.enabled); }
        if (InputCompat.GetKeyDown(KeyCode.Alpha3)) { if (particles.isPlaying) particles.Stop(); else particles.Play(); }
        if (InputCompat.GetKeyDown(KeyCode.Alpha4)) { fog = !fog; RenderSettings.fog = fog; }
        if (InputCompat.GetKeyDown(KeyCode.O)) orbit = !orbit;
        if (orbit)
        {
            angle += 40f * Time.deltaTime;
            orbitTarget.position = new Vector3(Mathf.Cos(angle * Mathf.Deg2Rad) * 6f, 0.5f, Mathf.Sin(angle * Mathf.Deg2Rad) * 6f);
        }
    }

    static AudioClip MakeChime()
    {
        const int sr = 44100; const int n = sr * 4;
        float[] notes = { 261.63f, 329.63f, 392f, 523.25f };
        var d = new float[n];
        for (int i = 0; i < n; i++)
        {
            float t = i / (float)sr; int idx = (int)t % 4; float lt = t % 1f;
            float env = Mathf.Exp(-3f * lt) * Mathf.Clamp01((1f - lt) * 20f);
            d[i] = (Mathf.Sin(2f * Mathf.PI * notes[idx] * t) * 0.4f + Mathf.Sin(4f * Mathf.PI * notes[idx] * t) * 0.1f) * env;
        }
        var c = AudioClip.Create("Chime", n, 1, sr, false); c.SetData(d, 0); return c;
    }

    void OnGUI()
    {
        ARVR.Hud("AUDIO & VISUAL EFFECTS\nSound comes from the metal cube (3D spatial audio) - fly around and listen (hold right mouse + WASD)\n" +
                 "[1] audio on/off   [2] point light   [3] particles   [4] fog   [O] make the sound source orbit", 14);
    }
}
