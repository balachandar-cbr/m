using UnityEngine;

public static class ExerciseBuilder
{
    public const string Title = "Exercise05 Audio and Visual Effects";

    public static void Build()
    {
        ARVR.ClearDefaults();
        ARVR.MakeSun(1f);
        var cam = ARVR.MakeCamera(new Vector3(0, 2f, -7f), new Vector3(10, 0, 0));
        cam.gameObject.AddComponent<FreeCam>();

        ARVR.Prim(PrimitiveType.Plane, "Ground", Vector3.zero, new Vector3(4, 1, 4), ARVR.Mat("Ex5_Ground", new Color(0.55f, 0.6f, 0.7f), 0f, 0.3f));

        // objects
        var cube = ARVR.Prim(PrimitiveType.Cube, "Cube", new Vector3(-1.2f, 0.5f, 0), Vector3.one, ARVR.Mat("Ex5_Metal", new Color(0.8f, 0.82f, 0.85f), 0.9f, 0.85f));
        ARVR.Prim(PrimitiveType.Sphere, "Sphere", new Vector3(1.5f, 0.5f, 0), Vector3.one, ARVR.Mat("Ex5_BlueGloss", new Color(0.1f, 0.3f, 0.9f), 0.2f, 0.95f));

        // PART A - 3D audio on the cube
        var src = cube.AddComponent<AudioSource>();
        src.playOnAwake = false; src.loop = true; src.volume = 0.8f;
        src.spatialBlend = 1f;                              // 1 = full 3D
        src.rolloffMode = AudioRolloffMode.Linear; src.minDistance = 1f; src.maxDistance = 25f;

        // PART B - light, material and particle effects
        var lamp = ARVR.Prim(PrimitiveType.Sphere, "LampBulb", new Vector3(-3.5f, 1.2f, 0), Vector3.one * 0.3f, ARVR.Emissive("Ex5_Bulb", new Color(1f, 0.7f, 0.2f), 3f), null, false);
        var pl = ARVR.MakePointLight("PointLight", new Vector3(-3.5f, 1.2f, 0), new Color(1f, 0.7f, 0.3f), 2f, 9f);

        var fire = new GameObject("Particles_Sparks"); fire.transform.SetParent(ARVR.Root(), false); fire.transform.position = new Vector3(3.8f, 0.05f, 0);
        fire.transform.rotation = Quaternion.Euler(-90, 0, 0);
        var ps = fire.AddComponent<ParticleSystem>();
        var main = ps.main; main.startColor = new Color(1f, 0.6f, 0.15f); main.startSize = 0.12f; main.startSpeed = 3.5f; main.startLifetime = 1.2f; main.loop = true; main.gravityModifier = 0.3f;
        var em = ps.emission; em.rateOverTime = 70f;
        var sh = ps.shape; sh.shapeType = ParticleSystemShapeType.Cone; sh.angle = 14f; sh.radius = 0.15f;
        var col = ps.colorOverLifetime; col.enabled = true;
        var grad = new Gradient();
        grad.SetKeys(new[] { new GradientColorKey(new Color(1f, 0.9f, 0.4f), 0f), new GradientColorKey(new Color(1f, 0.3f, 0.05f), 1f) },
                     new[] { new GradientAlphaKey(1f, 0f), new GradientAlphaKey(0f, 1f) });
        col.color = grad;
        var psr = fire.GetComponent<ParticleSystemRenderer>();
        psr.sharedMaterial = ARVR.UsingSRP ? ARVR.FromShader("Ex5_Particle", "Universal Render Pipeline/Particles/Unlit", "Sprites/Default")
                                           : ARVR.FromShader("Ex5_Particle", "Legacy Shaders/Particles/Additive", "Particles/Standard Unlit", "Sprites/Default");

        // PART B step 9 - camera/atmosphere effects (fog + background)
        RenderSettings.fogColor = new Color(0.7f, 0.8f, 0.95f);
        RenderSettings.fogMode = FogMode.ExponentialSquared;
        RenderSettings.fogDensity = 0.02f;

        var demo = new GameObject("AudioVisualDemo").AddComponent<AudioVisualDemo>();
        demo.transform.SetParent(ARVR.Root(), false);
        demo.audioSrc = src; demo.pointLight = pl; demo.particles = ps; demo.orbitTarget = cube.transform; demo.lampBulb = lamp;
    }
}
