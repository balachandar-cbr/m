using UnityEngine;

/// <summary>Shows a green indicator on the surface under the mouse; click to place a copy of the object.</summary>
public class PlacementIndicator : MonoBehaviour
{
    public GameObject indicator;
    public Camera cam;
    public GameObject placeablePrefab;      // the "PlaceableObject" cube (scene object or prefab)
    public bool placeOnClick = true;
    int placed;

    void Start() { if (cam == null) cam = Camera.main; }

    void Update()
    {
        if (cam == null || indicator == null) return;
        Ray ray = cam.ScreenPointToRay(InputCompat.MousePosition);
        RaycastHit hit;
        if (Physics.Raycast(ray, out hit))
        {
            indicator.SetActive(true);
            indicator.transform.position = hit.point + hit.normal * 0.01f;
            indicator.transform.up = hit.normal;
            if (placeOnClick && InputCompat.MouseButtonDown(0)) Place(hit);
        }
        else
        {
            indicator.SetActive(false);
        }
    }

    void Place(RaycastHit hit)
    {
        GameObject o = placeablePrefab != null ? Instantiate(placeablePrefab) : GameObject.CreatePrimitive(PrimitiveType.Cube);
        o.SetActive(true);
        o.name = "Placed_" + (++placed);
        o.transform.position = hit.point + hit.normal * (0.5f * o.transform.localScale.y);
        var r = o.GetComponent<Renderer>();
        if (r != null) r.material.color = Random.ColorHSV(0f, 1f, 0.5f, 0.8f, 0.8f, 1f);
    }

    void OnGUI() { ARVR.Hud("PLACEMENT INDICATOR\nMove the mouse: the green indicator follows the surface\nLeft click: place the object   (objects placed: " + placed + ")", 14); }
}
