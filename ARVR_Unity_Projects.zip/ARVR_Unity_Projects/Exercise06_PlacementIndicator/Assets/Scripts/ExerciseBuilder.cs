using UnityEngine;

public static class ExerciseBuilder
{
    public const string Title = "Exercise06 Placement Indicator";

    public static void Build()
    {
        ARVR.ClearDefaults();
        ARVR.MakeSun(1f);
        var cam = ARVR.MakeCamera(new Vector3(0, 6f, -8f), new Vector3(35, 0, 0));

        ARVR.Prim(PrimitiveType.Plane, "Ground", Vector3.zero, new Vector3(2, 1, 2), ARVR.Mat("Ex6_Ground", new Color(0.55f, 0.58f, 0.68f), 0f, 0.15f));
        var placeable = ARVR.Prim(PrimitiveType.Cube, "PlaceableObject", new Vector3(3.5f, 0.5f, 3f), Vector3.one, ARVR.Mat("Ex6_Cube", new Color(0.35f, 0.38f, 0.45f)));

        // flat green disc, no collider (otherwise it would block its own raycast)
        var ind = ARVR.Prim(PrimitiveType.Cylinder, "PlacementIndicator", new Vector3(0, 0.02f, 0), new Vector3(1f, 0.01f, 1f), ARVR.Mat("Ex6_Indicator", new Color(0.3f, 1f, 0.4f), 0f, 0.6f), null, false);
        ind.SetActive(false);

        var mgr = new GameObject("PlacementManager");
        mgr.transform.SetParent(ARVR.Root(), false);
        var pi = mgr.AddComponent<PlacementIndicator>();
        pi.indicator = ind; pi.cam = cam; pi.placeablePrefab = placeable;
    }
}
