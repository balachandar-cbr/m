using UnityEngine;

public static class ExerciseBuilder
{
    public const string Title = "Exercise10 Coin Animation";

    public static void Build()
    {
        ARVR.ClearDefaults();
        var cam = ARVR.MakeCamera(new Vector3(0, 0, -10f), Vector3.zero, null, true, new Color(0.30f, 0.45f, 0.85f));
        cam.orthographic = true; cam.orthographicSize = 3f;

        var coin = new GameObject("Coin");
        coin.transform.SetParent(ARVR.Root(), false);
        coin.AddComponent<SpriteRenderer>();
        var cs = coin.AddComponent<CoinSpin>();
        cs.fps = 12f;
        coin.transform.localScale = Vector3.one * 1.5f;
    }
}
