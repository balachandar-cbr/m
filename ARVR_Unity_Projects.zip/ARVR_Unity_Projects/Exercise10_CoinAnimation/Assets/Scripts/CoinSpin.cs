using UnityEngine;

/// <summary>
/// Frame-by-frame coin twist using sprites.  Press Space to flip the coin.
/// Frames are generated in code if you do not assign your own sprite sheet frames,
/// or assign an Animator whose state is named "CoinTwist" (as in the lab record).
/// </summary>
public class CoinSpin : MonoBehaviour
{
    public Animator animator;
    public Sprite[] frames;
    public float fps = 12f;
    public bool loopContinuously;

    SpriteRenderer sr;
    bool playing;
    float timer;

    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        if (frames == null || frames.Length == 0) frames = CoinSprites.Generate(12);
        sr.sprite = frames[0];
    }

    void Update()
    {
        if (InputCompat.GetKeyDown(KeyCode.L)) loopContinuously = !loopContinuously;
        if (InputCompat.GetKeyDown(KeyCode.Space))
        {
            if (animator != null && animator.runtimeAnimatorController != null) animator.Play("CoinTwist");
            else { playing = true; timer = 0f; }
        }
        if (playing)
        {
            timer += Time.deltaTime * fps;
            int idx = (int)timer;
            if (idx >= frames.Length)
            {
                if (loopContinuously) { timer = 0f; idx = 0; }
                else { playing = false; idx = 0; }
            }
            sr.sprite = frames[idx];
        }
        else if (loopContinuously) playing = true;
    }

    void OnGUI() { ARVR.Hud("2D COIN ANIMATION (sprites)\nSpace : twist the coin    L : loop continuously (" + (loopContinuously ? "ON" : "off") + ")", 16); }
}

/// <summary>Draws the rotation frames of a gold star coin into sprites (cos-scaled ellipse = 3D twist illusion).</summary>
public static class CoinSprites
{
    const int S = 128;

    public static Sprite[] Generate(int count)
    {
        var res = new Sprite[count];
        for (int f = 0; f < count; f++)
        {
            float ang = f / (float)count * Mathf.PI * 2f;
            float cx = Mathf.Cos(ang);
            float w = Mathf.Abs(cx);
            bool front = cx >= 0f;
            var pix = new Color32[S * S];
            Color gold = new Color(1f, 0.82f, 0.15f), rim = new Color(0.85f, 0.55f, 0.05f), edge = new Color(0.7f, 0.45f, 0.05f), star = new Color(1f, 0.95f, 0.5f);
            float R = S * 0.45f;
            for (int y = 0; y < S; y++)
                for (int x = 0; x < S; x++)
                {
                    float dx = x - S / 2f, dy = y - S / 2f;
                    Color c = Color.clear;
                    if (w < 0.08f)                                  // almost edge-on: thin rectangle
                    {
                        if (Mathf.Abs(dx) < 3f && Mathf.Abs(dy) < R) c = edge;
                    }
                    else
                    {
                        float nx = dx / (R * w), ny = dy / R;
                        float d = Mathf.Sqrt(nx * nx + ny * ny);
                        if (d <= 1f)
                        {
                            c = d > 0.84f ? rim : gold;
                            if (front && InStar(nx, ny)) c = star;
                            if (!front && d < 0.5f && d > 0.4f) c = rim;
                        }
                    }
                    pix[y * S + x] = c;
                }
            var tex = new Texture2D(S, S, TextureFormat.RGBA32, false);
            tex.SetPixels32(pix); tex.filterMode = FilterMode.Bilinear; tex.Apply();
            res[f] = Sprite.Create(tex, new Rect(0, 0, S, S), new Vector2(0.5f, 0.5f), 64f);
        }
        return res;
    }

    static bool InStar(float x, float y)
    {
        const float outer = 0.62f, inner = 0.26f;
        var v = new Vector2[10];
        for (int i = 0; i < 10; i++)
        {
            float a = (90f + i * 36f) * Mathf.Deg2Rad; float r = (i % 2 == 0) ? outer : inner;
            v[i] = new Vector2(Mathf.Cos(a) * r, Mathf.Sin(a) * r);
        }
        bool inside = false;
        for (int i = 0, j = 9; i < 10; j = i++)
            if (((v[i].y > y) != (v[j].y > y)) && (x < (v[j].x - v[i].x) * (y - v[i].y) / (v[j].y - v[i].y) + v[i].x)) inside = !inside;
        return inside;
    }
}
