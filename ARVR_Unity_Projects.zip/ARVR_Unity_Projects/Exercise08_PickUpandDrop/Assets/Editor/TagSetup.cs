#if UNITY_EDITOR
using UnityEditor;
using UnityEditorInternal;

/// <summary>Creates the "Pickup" tag automatically (Step 2 of the exercise).</summary>
[InitializeOnLoad]
public static class TagSetup
{
    static TagSetup()
    {
        if (System.Array.IndexOf(InternalEditorUtility.tags, "Pickup") < 0) InternalEditorUtility.AddTag("Pickup");
    }
}
#endif
