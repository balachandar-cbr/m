using UnityEngine;

public static class ExerciseBuilder
{
    public const string Title = "Exercise08 Pick Up and Drop";

    static void Pickable(GameObject g)
    {
        g.AddComponent<Rigidbody>();
        g.AddComponent<Pickable>();
        try { g.tag = "Pickup"; } catch (UnityException) { /* tag is created automatically by the Editor script */ }
    }

    public static void Build()
    {
        ARVR.ClearDefaults();
        ARVR.MakeSun(1f);
        ARVR.Prim(PrimitiveType.Plane, "Ground", Vector3.zero, new Vector3(3, 1, 3), ARVR.Mat("Ex8_Ground", new Color(0.6f, 0.62f, 0.68f), 0f, 0.1f));

        Pickable(ARVR.Prim(PrimitiveType.Cube, "PickupCube", new Vector3(0, 1f, 3f), Vector3.one, ARVR.Mat("Ex8_Cube", new Color(0.3f, 0.34f, 0.42f))));
        Pickable(ARVR.Prim(PrimitiveType.Sphere, "PickupSphere", new Vector3(-2f, 0.5f, 3f), Vector3.one * 0.7f, ARVR.Mat("Ex8_Sphere", new Color(0.95f, 0.8f, 0.2f), 0f, 0.8f)));

        // trigger object: press E while looking at it
        var trig = ARVR.Prim(PrimitiveType.Cylinder, "TriggerObject", new Vector3(2.5f, 0.5f, 3f), new Vector3(0.6f, 0.5f, 0.6f), ARVR.Mat("Ex8_Trigger", Color.red));
        var inter = trig.AddComponent<Interactable>(); inter.target = trig.GetComponent<Renderer>();

        // player: capsule controller + camera (0,1,0) + HoldPoint (0,0,1) in front of it
        var pl = new GameObject("Player");
        pl.transform.SetParent(ARVR.Root(), false);
        var cc = pl.AddComponent<CharacterController>();
        cc.height = 1.2f; cc.radius = 0.3f; cc.center = new Vector3(0, 0.6f, 0);
        var cam = ARVR.MakeCamera(new Vector3(0, 1f, 0), Vector3.zero, pl.transform);
        var fpc = pl.AddComponent<FirstPersonController>(); fpc.cam = cam; fpc.speed = 3f;

        var hold = new GameObject("HoldPoint");
        hold.transform.SetParent(cam.transform, false);
        hold.transform.localPosition = new Vector3(0, 0, 1f);

        var pi = cam.gameObject.AddComponent<PlayerInteraction>();
        pi.holdPosition = hold.transform;
    }
}
