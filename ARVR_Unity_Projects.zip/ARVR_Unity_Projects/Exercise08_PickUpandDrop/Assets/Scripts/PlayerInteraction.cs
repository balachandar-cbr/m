using UnityEngine;

public class Pickable : MonoBehaviour { }

/// <summary>Object that reacts to E (the "trigger object" of the lab): toggles red/green.</summary>
public class Interactable : MonoBehaviour
{
    public Renderer target;
    bool on;
    public void Activate() { on = !on; if (target != null) target.material.color = on ? Color.green : Color.red; }
}

/// <summary>Look at an object and press E to pick it up; press E again to drop it. (Record script, bug-fixed.)</summary>
public class PlayerInteraction : MonoBehaviour
{
    public float interactDistance = 3f;
    public Transform holdPosition;
    GameObject heldObject;
    string prompt = "";

    void Update()
    {
        prompt = "";
        RaycastHit hit = default(RaycastHit);
        if (heldObject == null && Physics.Raycast(transform.position, transform.forward, out hit, interactDistance, ~0, QueryTriggerInteraction.Ignore))
        {
            if (hit.collider.GetComponent<Pickable>() != null) prompt = "Press E to pick up " + hit.collider.name;
            else if (hit.collider.GetComponent<Interactable>() != null) prompt = "Press E to activate " + hit.collider.name;
        }
        else if (heldObject != null) prompt = "Press E to drop " + heldObject.name;

        if (InputCompat.GetKeyDown(KeyCode.E))
        {
            if (heldObject == null) PickUpObject(hit);
            else DropObject();
        }
    }

    void PickUpObject(RaycastHit hit)
    {
        if (hit.collider == null) return;
        var inter = hit.collider.GetComponent<Interactable>();
        if (inter != null) { inter.Activate(); return; }
        if (hit.collider.GetComponent<Pickable>() == null) return;

        heldObject = hit.collider.gameObject;
        var rb = heldObject.GetComponent<Rigidbody>();
        rb.useGravity = false;
        rb.isKinematic = true;
        hit.collider.enabled = false;                       // so the held object cannot push the player
        heldObject.transform.SetParent(holdPosition);
        heldObject.transform.localPosition = Vector3.zero;
        heldObject.transform.localRotation = Quaternion.identity;
    }

    void DropObject()
    {
        var rb = heldObject.GetComponent<Rigidbody>();
        heldObject.transform.SetParent(null);
        var col = heldObject.GetComponent<Collider>(); if (col != null) col.enabled = true;
        rb.isKinematic = false;
        rb.useGravity = true;
        heldObject = null;
    }

    void OnGUI()
    {
        ARVR.Hud("USER INTERACTION - PICK UP & DROP\nWASD move | Mouse look | E pick up / drop / activate", 14);
        ARVR.Text(new Rect(Screen.width / 2 - 10, Screen.height / 2 - 12, 20, 24), "+", 18, TextAnchor.MiddleCenter);
        if (prompt != "") ARVR.Text(new Rect(0, Screen.height * 0.62f, Screen.width, 40), prompt, 20, TextAnchor.MiddleCenter, true);
    }
}
