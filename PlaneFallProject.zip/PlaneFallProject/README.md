# PlaneFallProject

Unity project: a Player cube moves on a Plane with WASD. If it leaves the Plane, it falls.

## Open it
1. Unity Hub -> Add -> select this `PlaneFallProject` folder (made with Unity 2022.3 LTS; newer versions will offer to upgrade).
2. Open `Assets/Scenes/MainScene.unity`.
3. Press Play.

## Scene contents
- Plane: position (0, 0, 0), scale (1, 1, 1), has a Mesh Collider.
- Player: Cube at (0, 0.5, 0) with Box Collider, Rigidbody (Use Gravity on) and `PlayerMovement`.
- Main Camera and Directional Light.

## Controls
W / S = forward / back, A / D = left / right.

Note: `Input.GetAxis` needs the old Input Manager. If you use a Unity version that defaults to the new Input System,
set Edit -> Project Settings -> Player -> Active Input Handling to "Input Manager (Old)" or "Both".
