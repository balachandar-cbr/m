UNITY PICKUP & DROP DEMO

Included:
- PlayerMovement.cs: Move using W/A/S/D or arrow keys.
- PlayerInteraction.cs: Press E to pick up or drop the cube.
- CreatePickupDropScene.cs: Creates the demo scene and connects the references.

SETUP
1. Extract this ZIP.
2. Open Unity Hub.
3. Click Add > Add project from disk and select this folder.
4. Open the project and wait for importing to finish.
5. In Unity, choose Tools > Pickup Drop Demo > Create Scene.
6. Open Assets/Scenes/PickupDropDemo.unity if it did not open automatically.
7. Press Play.
8. Use W/A/S/D or arrow keys to move. Aim at the cube and press E to pick it up; press E again to drop it.

IMPORTANT
- This project uses Unity's Input System package.
- The cube is tagged "Pickup"; the editor scene builder assigns the tag when creating it.
- If Unity prompts for Active Input Handling, choose Input System Package (New) or Both, then restart Unity.
- If the project opens with a different Unity version, allow Unity to upgrade the project when prompted.
