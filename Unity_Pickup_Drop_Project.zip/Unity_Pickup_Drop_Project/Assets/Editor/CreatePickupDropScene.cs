using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class CreatePickupDropScene
{
    [MenuItem("Tools/Pickup Drop Demo/Create Scene")]
    public static void CreateScene()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            return;

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        // Ground
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground";
        ground.transform.position = Vector3.zero;
        ground.transform.localScale = new Vector3(2f, 1f, 2f);

        // Player
        GameObject player = new GameObject("Player");
        player.transform.position = new Vector3(0f, 1f, -4f);
        CharacterController cc = player.AddComponent<CharacterController>();
        cc.height = 2f;
        cc.radius = 0.35f;
        cc.center = new Vector3(0f, 0f, 0f);
        player.AddComponent<PlayerMovement>();

        // Hold point in front of the player
        GameObject holdPoint = new GameObject("HoldPoint");
        holdPoint.transform.SetParent(player.transform);
        holdPoint.transform.localPosition = new Vector3(0f, 0.1f, 1.5f);
        holdPoint.transform.localRotation = Quaternion.identity;

        // Camera
        GameObject cameraObject = new GameObject("Main Camera");
        cameraObject.tag = "MainCamera";
        Camera cam = cameraObject.AddComponent<Camera>();
        cameraObject.AddComponent<AudioListener>();
        cameraObject.transform.position = new Vector3(0f, 2.7f, -7.5f);
        cameraObject.transform.rotation = Quaternion.Euler(12f, 0f, 0f);

        // Aim camera at the pickup cube area
        cameraObject.transform.SetParent(player.transform);
        cameraObject.transform.localPosition = new Vector3(0f, 1.2f, -0.2f);
        cameraObject.transform.localRotation = Quaternion.Euler(8f, 0f, 0f);

        PlayerInteraction interaction = player.AddComponent<PlayerInteraction>();
        interaction.holdPoint = holdPoint.transform;
        interaction.playerCamera = cam;

        // Pickup cube
        GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.name = "PickupCube";
        cube.transform.position = new Vector3(0f, 0.5f, 0f);
        cube.tag = "Pickup";
        Rigidbody rb = cube.AddComponent<Rigidbody>();
        rb.mass = 1f;

        // A simple directional light
        GameObject lightObject = new GameObject("Directional Light");
        Light light = lightObject.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.2f;
        lightObject.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

        string folder = "Assets/Scenes";
        if (!AssetDatabase.IsValidFolder(folder))
            AssetDatabase.CreateFolder("Assets", "Scenes");

        EditorSceneManager.SaveScene(scene, folder + "/PickupDropDemo.unity");
        AssetDatabase.SaveAssets();
        Debug.Log("Pickup/drop demo scene created at Assets/Scenes/PickupDropDemo.unity");
    }
}
