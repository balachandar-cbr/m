using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerInteraction : MonoBehaviour
{
    [Header("References")]
    public Transform holdPoint;
    public Camera playerCamera;

    [Header("Settings")]
    public float pickupRange = 5f;

    private GameObject heldObject;

    void Update()
    {
        if (Keyboard.current == null || !Keyboard.current.eKey.wasPressedThisFrame)
            return;

        if (heldObject != null)
        {
            DropObject();
            return;
        }

        if (playerCamera == null || holdPoint == null)
        {
            Debug.LogWarning("Assign Player Camera and Hold Point in the Inspector.");
            return;
        }

        Ray ray = new Ray(playerCamera.transform.position, playerCamera.transform.forward);

        if (Physics.Raycast(ray, out RaycastHit hit, pickupRange))
        {
            Rigidbody rb = hit.collider.attachedRigidbody;

            if (rb != null && hit.collider.CompareTag("Pickup"))
                PickUpObject(rb.gameObject, rb);
        }
    }

    void PickUpObject(GameObject obj, Rigidbody rb)
    {
        heldObject = obj;
        rb.isKinematic = true;
        rb.useGravity = false;
        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;

        heldObject.transform.SetParent(holdPoint);
        heldObject.transform.localPosition = Vector3.zero;
        heldObject.transform.localRotation = Quaternion.identity;

        Debug.Log("Object picked up!");
    }

    void DropObject()
    {
        Rigidbody rb = heldObject.GetComponent<Rigidbody>();
        heldObject.transform.SetParent(null);

        if (rb != null)
        {
            rb.isKinematic = false;
            rb.useGravity = true;
        }

        heldObject = null;
        Debug.Log("Object dropped!");
    }
}
