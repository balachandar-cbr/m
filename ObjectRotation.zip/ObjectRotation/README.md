# ObjectRotation

Unity project: a Sphere at (0, 0, 0) rotates around its own Y axis. Q rotates left, E rotates right.

## Open it
1. Unity Hub -> Add -> select this `ObjectRotation` folder (made with Unity 2022.3 LTS; newer versions will offer to upgrade).
2. Open `Assets/Scenes/MainScene.unity`.
3. Press Play, then hold Q or E.

## Contents
- Sphere with `RotateObject` attached (Rotation Speed = 100, editable in the Inspector).
- Main Camera at (0, 0, -4) and a Directional Light.

Note: the script uses `Input.GetKey`, which needs the old Input Manager. If your Unity version defaults to the new
Input System, set Edit -> Project Settings -> Player -> Active Input Handling to "Input Manager (Old)" or "Both".
