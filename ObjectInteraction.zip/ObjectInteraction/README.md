# ObjectInteraction

Unity project: look at the cube and press E to pick it up; press E again to drop it.

## Open it
1. Unity Hub -> Add -> select this `ObjectInteraction` folder (made with Unity 2022.3 LTS; newer versions will offer to upgrade).
2. Open `Assets/Scenes/MainScene.unity`.
3. Press Play, then press E while looking at the cube.

## Scene contents
- Plane at (0, 0, 0).
- PickupCube at (0, 1, 3), tag `Pickup`, with a Rigidbody (Use Gravity on).
- Main Camera at (0, 1, 0) with `PlayerInteraction` (Interact Distance 3, Hold Position = HoldPoint).
- HoldPoint: child of Main Camera at local (0, 0, 1).
- Directional Light.

## Camera rotation
A default Unity camera looks along +Z, and the cube is at +Z, so the camera rotation is (0, 0, 0).
Do not rotate it to Y = 180: that would turn it away from the cube and the pickup raycast would miss.

Note: the script uses `Input.GetKeyDown`, which needs the old Input Manager. If your Unity version defaults to the new
Input System, set Edit -> Project Settings -> Player -> Active Input Handling to "Input Manager (Old)" or "Both".
